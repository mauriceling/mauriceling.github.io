import pnet

    #b = # contact rate
    #s = # latency rate
    #g = # recovery rate
    #w = # loss of immunity rate 

net = pnet.PNet()

b = 0.21    # contact rate
s = 1/7     # latency rate
g = 1/14    # recovery rate
w = 1/365   # loss of immunity rate 

# The Compartments
net.add_places('S', {'S': 0.999})
net.add_places('E', {'E': 0.001})
net.add_places('I', {'I': 0})
net.add_places('R', {'R': 0})

def susceptible_exposed(places): 
    S = places['S'].attributes['S']
    I = places['I'].attributes['I']
    return b * S * I

def exposed_infected(places):
    E = places['E'].attributes['E']
    return s * E

def infected_recovered(places):
    I = places['I'].attributes['I']
    return g * I
    
def recovered_susceptible(places):
    R = places['R'].attributes['R']
    return w * R
    
net.add_rules('exposed', 'function', 
              ['S.S -> E.E', 
               susceptible_exposed, 
               'S.S > 0'])

net.add_rules('infection', 'function', 
              ['E.E -> I.I', 
               exposed_infected, 
               'E.E > 0'])

net.add_rules('recovery', 'function', 
              ['I.I -> R.R', 
               infected_recovered, 
               'I.I > 0'])

net.add_rules('resusceptible', 'function', 
              ['R.R -> S.S', 
               recovered_susceptible, 
               'R.R > 0'])

net.simulate(100, 1, 1)

from pprint import pprint
pprint(net.rules)

data = net.report_tokens()
headers = ['timestep'] + data[0][1]

f = open('seirs.csv', 'w')
f.write(','.join(headers) + '\n')
for tdata in data:
    tdata = [tdata[0]] + [str(x) for x in tdata[2]]
    f.write(','.join(tdata) + '\n')
f.close()
