# -*- coding: utf-8 -*-
"""
Baseline chatbot (DumbBot), which receives no training
"""

from chatterbot import ChatBot

try: os.remove("./dumbBot_chat.db")
except: pass

# Uncomment the following lines to enable verbose logging
#import logging
#logging.basicConfig(level=logging.INFO)

# Create a new instance of a ChatBot
bot = ChatBot(
    'DumbBot',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    logic_adapters=['chatterbot.logic.BestMatch'],
    database_uri='sqlite:///dumbBot_chat.db'
)

print('Type something to begin...')

# The following loop will execute each time the user enters input
while True:
    try:
        user_input = input("Talk to DumbBot > ")
        bot_response = bot.get_response(user_input)
        print("DumbBot: " + str(bot_response))

    # Press ctrl-c or ctrl-d on the keyboard to exit
    except (KeyboardInterrupt, EOFError, SystemExit):
        break