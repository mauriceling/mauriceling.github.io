import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Read excel file
df = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\Control_met_sum.xlsx")
df1 = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\MetaboliteSum_met_sum.xlsx")
df2 = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\MetaboliteAverage_met_sum.xlsx")
df3 = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\MetaboliteUnique_met_sum.xlsx")

#PLOT
sns.lineplot(data=df, x='generation', y='met_sum', label='Control', errorbar='se', err_style='bars')
sns.lineplot(data=df1, x='generation', y='met_sum', label='Metabolite Sum', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)
sns.lineplot(data=df2, x='generation', y='met_sum', label='Metabolite Average', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)
sns.lineplot(data=df3, x='generation', y='met_sum', label='Metabolite Unique', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)

plt.title("Grand mean of metabolite sum across 1000 generations")
plt.xlabel('Generation')
plt.ylabel('Grand mean of metabolite sum')
plt.xticks([100,200,300,400,500,600,700,800,900,1000])

plt.show()