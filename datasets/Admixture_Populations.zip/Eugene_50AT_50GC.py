'''
Example 31: Construct World and Population from scratch.

In this simulation,
    - construct world
    - construct 1 population of 5 organisms with different genome 
    for each organism
    - 100 generations to be simulated
'''
# needed to run this example without prior
# installation of DOSE into Python site-packages
try: 
  import run_examples_without_installation
except ImportError: pass

import copy
import random

# Example codes starts from here
import dose

parameters = {# Part 1: Simulation metadata
              "simulation_name": "eugene_control_AT",
              "population_names": ['pop_AT'],

              # Part 2: World settings
              "world_x": 1,
              "world_y": 1,
              "world_z": 1,
              "population_locations": [[(0,0,0)]],
              "eco_cell_capacity": 1000,
              "deployment_code": None,

              # Part 3: Population settings
              "population_size": 100,

              # Part 4: Genetics settings
              "genome_size": 1,
              "chromosome_size": 2000,
              "chromosome_bases": ['A', 'T'],
              "initial_chromosome": ['A', 'T'] * 600,

              # Part 5: Mutation settings
              "background_mutation": 0.01,
              "additional_mutation": 0,
              "mutation_type": 'point',
              
              # Part 6: Metabolic settings
              "interpreter": 'ragaraja',
              "instruction_size": 3,
              "ragaraja_version": 0,
              "base_converter": None,
              "ragaraja_instructions": [],
              "max_tape_length": 50,
              "interpret_chromosome": False,
              "clean_cell": False,
              "max_codon": 2000,

              # Part 7: Simulation settings
              "goal": 0,
              "maximum_generations": 100,
              "eco_buried_frequency": 100,
              "fossilized_ratio": 0.01,
              "fossilized_frequency": 20,
              
              # Part 8: Simulation report settings
              "print_frequency": 10,
              "database_file": "simulation.db",
              "database_logging_frequency": 1
             }

class simulation_functions(dose.dose_functions):

    def organism_movement(self, Populations, pop_name, World): pass

    def organism_location(self, Populations, pop_name, World): pass

    def ecoregulate(self, World): pass

    def update_ecology(self, World, x, y, z): pass

    def update_local(self, World, x, y, z): pass

    def report(self, World): pass

    def fitness(self, Populations, pop_name):
        pass

    def mutation_scheme(self, organism): 
        organism.genome[0].rmutate(parameters["mutation_type"],
                                   parameters["additional_mutation"])

    def prepopulation_control(self, Populations, pop_name): 
        pass

    def mating(self, Populations, pop_name): 
        for location in parameters["population_locations"][0]:
            group = dose.filter_location(location, Populations[pop_name].agents)
            for x in range(len(group)//2):
                parents = []
                for i in range(2):
                    parents.append(random.choice(Populations[pop_name].agents))
                    while parents[i] not in group:
                        parents[i] = random.choice(Populations[pop_name].agents)
                    Populations[pop_name].agents.remove(parents[i])
                crossover_pt = random.randint(0, len(parents[0].genome[0].sequence))
                (new_chromo1, new_chromo2) = dose.genetic.crossover(parents[0].genome[0], 
                                                               parents[1].genome[0], 
                                                               crossover_pt)
                children = [dose.genetic.Organism([new_chromo1],
                                             parameters["mutation_type"],
                                             parameters["additional_mutation"]),
                            dose.genetic.Organism([new_chromo2],
                                             parameters["mutation_type"],
                                             parameters["additional_mutation"])]
                for child in children:
                    child.status['parents'] = [parents[0].status['identity'], 
                                               parents[1].status['identity']]
                    child.status['location'] = location
                    child.status['generation'] = parents[0].status["generation"] + 1
                    child.generate_name()
                    child.status['deme'] = pop_name
                    Populations[pop_name].agents.append(child)

    def postpopulation_control(self, Populations, pop_name): pass

    def generation_events(self, Populations, pop_name): pass

    def population_report(self, Populations, pop_name):
        agents = Populations[pop_name].agents
        sequences = [''.join(org.genome[0].sequence) for org in agents]
        identities = [org.status['identity'] for org in agents]
        gen_count = agents[0].status["generation"]
        for index in range(len(agents)):
            print('> %s|%s' % (str(gen_count), str(identities[index])))
            print(str(sequences[index]))

    def database_report(self, con, cur, start_time, 
                        Populations, World, generation_count):
        try: dose.database_report_populations(con, cur, start_time, 
                                    Populations, generation_count)
        except: pass
        try: dose.database_report_world(con, cur, start_time, 
                                        World, generation_count)
        except: pass

    def deployment_scheme(self, Populations, pop_name, World): pass

print('\n[' + parameters["simulation_name"].upper() + ' SIMULATION]')
print('Adding deployment scheme to simulation parameters...')
parameters["deployment_scheme"] = simulation_functions.deployment_scheme

# Step 1: Construct World
print('Constructing World entity...')
# World(parameters["world_x"], parameters["world_y"], parameters["world_z"])
World = dose.dose_world.World(1, 1, 1)
#World = dose.load_all_local_input(World, [1, 2])

# Step 2: Construct Population(s)
n_AT = 50
n_GC = 50

pop_01 = {}
for i in range(1, n_AT+1):
  identity = "AT" + str(i)
  genome = [['A', 'T'] * 600]
  pop_01[identity] = {"status": {"alive": True, "vitality": 100.0, 
                                 "parents": None, "age": 0.0, 
                                 "gender": None, "lifespan": 100.0, 
                                 "fitness": 0.0, "blood": None, 
                                 "identity": identity, "deme": "pop_01", 
                                 "location": (0,0,0), "generation": 0, 
                                 "death": None},
                     "genome": genome,
                     "bases": parameters["chromosome_bases"],
                     "background_mutation": parameters["background_mutation"],
                     "additional_mutation": parameters["additional_mutation"],
                     "mutation_type": parameters["mutation_type"]}
  for i in range(1, n_GC+1):
    identity = "GC" + str(i)
    genome = [['G', 'C'] * 600]
    pop_01[identity] = {"status": {"alive": True, "vitality": 100.0, 
                                   "parents": None, "age": 0.0, 
                                   "gender": None, "lifespan": 100.0, 
                                   "fitness": 0.0, "blood": None, 
                                   "identity": identity, "deme": "pop_01", 
                                   "location": (0,0,0), "generation": 0, 
                                   "death": None},
                       "genome": genome,
                       "bases": parameters["chromosome_bases"],
                       "background_mutation": parameters["background_mutation"],
                       "additional_mutation": parameters["additional_mutation"],
                       "mutation_type": parameters["mutation_type"]}

def construct_PopDiffOrg(World, parameters, population_dictionary):
  organisms = []
  for org_key in population_dictionary:
    orgData = population_dictionary[org_key]
    chromosomes = [dose.genetic.Chromosome(chr_seq,
                    orgData["bases"], orgData["background_mutation"])
                    for chr_seq in orgData["genome"]]
    organism = dose.genetic.Organism(chromosomes,
                                      orgData['mutation_type'],
                                      orgData['additional_mutation'])
    organism.status = orgData["status"]
    x = orgData["status"]["location"][0]
    y = orgData["status"]["location"][1]
    z = orgData["status"]["location"][2]
    World.ecosystem[x][y][z]["organisms"] = World.ecosystem[x][y][z]["organisms"] + 1
    organisms.append(organism)
  population = dose.genetic.Population(parameters["goal"],
                                       parameters["maximum_generations"],
                                       organisms)
  return (World, population)

(World, population_01) = construct_PopDiffOrg(World, parameters, pop_01)
Populations = {'pop_01': population_01}

# Step 3: Simulate
print('\nStarting simulation on sequential ecological cell simulator...')
(simulation_functions, parameters, Populations, World) = \
    dose.sequential_simulator(simulation_functions, parameters, 
                              Populations, World)
print('\nSimulation ended...')
