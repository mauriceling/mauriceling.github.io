import sys
import os
import unittest

import copadsIII as N


class testCauchy(unittest.TestCase):
    def testCDF1(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).CDF(0.0)
        self.assertAlmostEqual(p, 0.5, places=4)
    def testCDF2(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).CDF(1.0)
        self.assertAlmostEqual(p, 0.75, places=4)
    def testCDF3(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).CDF(2.0)
        self.assertAlmostEqual(p, 0.85241, places=4)
    def testPDF1(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).PDF(0.0)
        self.assertAlmostEqual(p, 0.31830, places=4)
    def testPDF2(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).PDF(1.0)
        self.assertAlmostEqual(p, 0.15915, places=4)
    def testPDF3(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).PDF(2.0)
        self.assertAlmostEqual(p, 0.06366, places=4)
    def testinverseCDF1(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).inverseCDF(0.5)[0]
        self.assertAlmostEqual(p, 0)
    def testinverseCDF2(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).inverseCDF(0.75)[0]
        self.assertAlmostEqual(p, 1.0)
    def testinverseCDF3(self):
        p = N.CauchyDistribution(location = 0.0, scale = 1.0).inverseCDF(0.8524163)[0]
        self.assertAlmostEqual(p, 2.0)
        

class testCosine(unittest.TestCase):
    def testCDF1(self):
        p = N.CosineDistribution(location = 0.0, scale = 1.0).CDF(0.0)
        self.assertAlmostEqual(p, 0.5, places=2)
    def testCDF2(self):
        p = N.CosineDistribution(location = 0.0, scale = 1.0).CDF(1.0)
        self.assertAlmostEqual(p, 0.793079, places=4)
    def testCDF3(self):
        p = N.CosineDistribution(location = 0.0, scale = 1.0).CDF(10.0)
        self.assertAlmostEqual(p, 2.00496578, places=4)
    def testinverseCDF1(self):
        p = N.CosineDistribution(location = 0.0,
                                  scale = 1.0).inverseCDF(2.00496578)[0]
        self.assertAlmostEqual(p, 10.0, places=2)
    def testinverseCDF2(self):
        p =  N.CosineDistribution(location = 0.0,
                                  scale = 1.0).inverseCDF(0.5)[0]
        self.assertAlmostEqual(p, 0.0, places=2)
    def testPDF1(self):
        p = N.CosineDistribution(location = 0.0, scale = 1.0).PDF(0.0)
        self.assertAlmostEqual(p, 0.318309, places=4)
    def testPDF2(self):
        p = N.CosineDistribution(location = 0.0, scale = 1.0).PDF(1.0)
        self.assertAlmostEqual(p, 0.245147, places=4)
    def testPDF3(self):
        p = N.CosineDistribution(location = 0.0, scale = 1.0).PDF(10.0)
        self.assertAlmostEqual(p, 0.02561256, places=4)
    def testVariance(self):
        p = N.CosineDistribution(location = 0.0, scale = 1.0).variance()
        self.assertAlmostEqual(p, 1.289868, places=4)
 
        
class testExponential(unittest.TestCase):
    def testCDF1(self):
        p = N.ExponentialDistribution(location = 0.0, scale = 1.0).CDF(0.0)
        self.assertAlmostEqual(p, 0.0, places = 2)
    def testCDF2(self):
        p = N.ExponentialDistribution(location = 0.0, scale = 1.0).CDF(2.0)
        self.assertAlmostEqual(p, 0.86466, places = 4)
    def testCDF3(self):
        p = N.ExponentialDistribution(location = 1.0, scale = 1.0).CDF(0.0)
        self.assertAlmostEqual(p, - 1.7182818, places = 4)
    def testPDF1(self):
        p = N.ExponentialDistribution(location = 0.0, scale = 1.0).PDF(0.0)
        self.assertAlmostEqual(p, 1.0, places = 4)
    def testPDF2(self):
        p = N.ExponentialDistribution(location = 0.0, scale = 1.0).PDF(1.0)
        self.assertAlmostEqual(p, 0.3679, places = 4)
    def testvariance(self):
        p = N.ExponentialDistribution(location = 0.0, scale = 1.0).variance()
        self.assertAlmostEqual(p, 1.0, places = 4)
    def testmean(self):
        p = N.ExponentialDistribution(location = 0.0, scale = 1.0).mean()
        self.assertAlmostEqual(p, 1.0, places = 4)
    def testmedian(self):
        p = N.ExponentialDistribution(location = 0.0, scale = 1.0).median()
        self.assertAlmostEqual(p, 0.30103, places = 4)
 
 
class testHypergeometric(unittest.TestCase):
    def testPDF(self):
        p = N.HypergeometricDistribution(sample_size=10,
                                population_size=100, 
                                population_success=50).PDF(5)
        self.assertAlmostEqual(p, 0.259333,  places = 2)
    def testCDF(self):
        p = N.HypergeometricDistribution(sample_size=10,
                                population_size=100, 
                                population_success=50).CDF(5)
        self.assertAlmostEqual(p, 0.629073,  places = 2)
    def testinverseCDF(self):
        p = N.HypergeometricDistribution(sample_size=10,
                            population_size=100, 
                            population_success=50).inverseCDF(0.629073)[0]
        self.assertAlmostEqual(p, 5,  places = 2)
    def testmean(self):
        p = N.HypergeometricDistribution(sample_size=10,
                                population_size=100, 
                                population_success=50).mean()
        self.assertAlmostEqual(p, 5.000,  places = 2)
    def testmode(self):
        p = N.HypergeometricDistribution(sample_size=10,
                                population_size=100, 
                                population_success=50).mode()
        self.assertAlmostEqual(p, 5.500,  places = 2)
    def testvariance(self):
        p = N.HypergeometricDistribution(sample_size=10,
                                population_size=100, 
                                population_success=50).variance()
        self.assertAlmostEqual(p, 2.272727,  places = 2)
        
        
class testLogarithmic(unittest.TestCase):
    def testPDF(self):
        p = N.LogarithmicDistribution(shape=0.45).PDF(1.0)
        self.assertAlmostEqual(p, 1.7332, places=4)
    def testCDF(self):
        p = N.LogarithmicDistribution(shape=0.45).CDF(0.0)
        self.assertAlmostEqual(p, 0.0, places=2)
    def testinverseCDF(self):
        p = N.LogarithmicDistribution(shape=0.45).CDF(0.0)
        self.assertAlmostEqual(p,0.0, places=2)
    def testmode(self):
        p = N.LogarithmicDistribution(shape=0.45).mode()
        self.assertAlmostEqual(p, 1.0, places=2)
    def testmean(self):
        p = N.LogarithmicDistribution(shape=0.45).mean()
        self.assertAlmostEqual(p, 3.15124, places=4)
        
        
class testSemicircular(unittest.TestCase):
    def testPDF1(self):
        p = N.SemicircularDistribution(location=0.0, scale=1.0).PDF(0.0)
        self.assertAlmostEqual(p, 0.63662, places=4)
    def testPDF2(self):
        p = N.SemicircularDistribution(location=0.0, scale=1.0).PDF(0.5)
        self.assertAlmostEqual(p, 0.55133, places=4)
    def testCDF1(self):
        p = N.SemicircularDistribution(location=0.0, scale=1.0).CDF(0.0)
        self.assertAlmostEqual(p, 0.5, places=4)
    def testCDF2(self):
        p = N.SemicircularDistribution(location=0.0, scale=1.0).CDF(0.5)
        self.assertAlmostEqual(p, 0.804498, places = 4)
    def testinverseCDF(self):
        p = N.SemicircularDistribution(location=0.0,
                                       scale=1.0).inverseCDF(0.5)[0]
        self.assertAlmostEqual(p, 0.0, places = 2)
        
        
class testTriangular(unittest.TestCase):
    def testCDF1(self):
       p = N.TriangularDistribution(2.0, 1.0).CDF(1.0)
       self.assertAlmostEqual(p, 0.5000, places=4)
    def testCDF2(self):
       p = N.TriangularDistribution(2.0, 1.0).CDF(0.8)
       self.assertAlmostEqual(p, 0.3200, places=4)
    def testCDF3(self):
       p = N.TriangularDistribution(4.0, 2.0, -4).CDF(1.0)
       self.assertAlmostEqual(p, 0.5208, places=4)
    def testPDF1(self):
       p = N.TriangularDistribution(2.0, 1.0).PDF(0.08)
       self.assertAlmostEqual(p, 0.08000, places=4)
    def testPDF2(self):
       p = N.TriangularDistribution(4.0, 2.0, -4).PDF(1.0)
       self.assertAlmostEqual(p, 0.20833, places=4)
    def testkurtosis(self):
       p = N.TriangularDistribution(2.0, 1.0).kurtosis()
       self.assertAlmostEqual(p, -0.6, places=4)
       
       
class testWeibull(unittest.TestCase):
    def testCDF1(self):
        p = N.WeiBullDistribution(location=1.0, 
                    scale=1.0).CDF(2)
        self.assertAlmostEqual(p, 0.864664, places=5)
    def testCDF2(self):
        p = N.WeiBullDistribution(location=2.0, 
                    scale=2.0).CDF(2)
        self.assertAlmostEqual(p, 0.632120, places=5)
    def testPDF1(self):
        p = N.WeiBullDistribution(location=1.0, 
                    scale=1.0).PDF(2)
        self.assertAlmostEqual(p, 0.135335, places=5)
    def testinverseCDF1(self):
        p = N.WeiBullDistribution(location=1.0, 
                    scale=1.0).inverseCDF(0.864664)[0]
        self.assertAlmostEqual(p, 2.000000, places=5)
    def testinverseCDF2(self):
        p = N.WeiBullDistribution(location=2.0, 
                    scale=2.0).inverseCDF(0.632120)[0]
        self.assertAlmostEqual(p, 2.000000, places=5)
    def testmedian(self):
        p = N.WeiBullDistribution(location=2.0, 
                    scale=2.0).median()
        self.assertAlmostEqual(p, 1.665109, places=5)
    def testmode(self):
        p = N.WeiBullDistribution(location=2.0, 
                    scale=2.0).mode()
        self.assertAlmostEqual(p, 1.414213, places=5)

        
if __name__ == '__main__':
    unittest.main()
