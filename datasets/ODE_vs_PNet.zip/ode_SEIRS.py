import ode

b = 0.21    # contact rate
s = 1/7     # latency rate
g = 1/14    # recovery rate
w = 1/365   # loss of immunity rate 
              
def S(t, y):
    incoming = w*y[3]
    outgoing = b*y[0]*y[2]
    return incoming - outgoing

def E(t, y):
    incoming = b*y[0]*y[2]
    outgoing = s*y[1]
    return incoming - outgoing

def I(t, y):
    incoming = s*y[1]
    outgoing = g*y[2]
    return incoming - outgoing

def R(t, y):
    incoming = g*y[2]
    outgoing = w*y[3]
    return incoming - outgoing

f = [S, E, I , R]   # system of ODEs

y = [0.999, 0.001, 0, 0]  # initial S, E, I, R proportion of population respectively
print('Solving using 4th order Runge Kutta method ......')
for i in [x for x in ode.Euler(f, 0.0, y, 1, 100.0)]:
    print(','.join([str(z) for z in i]))
print('')

