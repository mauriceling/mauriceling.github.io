"""
Data Structures and Algorithms for Data Collected from One or More Samples.

The following functions were adapted from http://www.nmr.mgh.harvard.edu/
Neural_Systems_Group/gary/python/stats.py (assumes 1-dimensional list as 
input):
    - geometricMean
    - harmonicMean
    - arithmeticMean
    - median
    - medianScore
    - mode
    - moment
    - variation
    - skew
    - kurtosis

Copyright (c) Maurice H.T. Ling <mauriceling@acm.org>
"""

import math
from copadsexceptions import FunctionParameterTypeError
from copadsexceptions import FunctionParameterValueError

class SingleSample:
    """
    Class to hold a single sample, and provides calculations on the sample
    """
    data = None
    rowcount = 0
    name = None
    summary = {}
    
    def __init__(self, data, name='Sample 1'):
        self.data = data
        self.rowcount = len(self.data)
        self.name = name
        
    def geometricMean(self):
        """
        Calculates the geometric mean of the data
        """
        mult = 1.0
        one_over_n = 1.0 / len(self.data)
        for item in self.data: mult = mult * math.pow(item, one_over_n)
        return mult
    
    def harmonicMean(self):
        """
        Calculates the harmonic mean of the data
        """
        sum = 0.000001
        for item in self.data:
            if item != 0: sum = sum + 1.0/item
            else: sum = sum + 1.0/0.001
        return len(self.data) / sum
    
    def arithmeticMean(self):
        """
        Returns the arithematic mean of the data
        """
        sum = 0
        for item in self.data: sum = sum + item
        return sum / float(len(self.data))
    
    def moment(self, moment=1):
        """
        Calculates the nth moment about the mean for the data
        """
        if moment == 1:
            return 0.0
        else:
            mn = self.arithmeticMean()
            n = len(self.data)
            s = 0
            for x in self.data:
                s = s + (x - mn) ** moment
            return s / float(n)
        
    def skew(self):
        """
        Returns the skewness of the data, as defined in Numerical
        Recipies (alternate defn in CRC Standard Probability and
        Statistics, p.6.)
        """
        return self.moment(3) / math.pow(self.moment(2), 1.5)

    def kurtosis(self):
        """
        Returns the kurtosis of the data, as defined in Numerical
        Recipies (alternate defn in CRC Standard Probability and
        Statistics, p.6.)
        """
        return self.moment(4) / math.pow(self.moment(2), 2.0)
    
    def variation(self):
        """
        Returns the coefficient of variation in percentage, as
        defined in CRC Standard Probability and Statistics, p.6.
        Ref: http://en.wikipedia.org/wiki/Coefficient_of_variation
        """
        return 100.0 * self.summary['stdev'] / self.summary['aMean']

    def range(self):
        """
        Returns the range of the data (maximum - minimum)
        """
        self.data.sort()
        return float(self.data[-1]) - float(self.data[0])

    def variance(self):
        """
        Returns the variance of the data
        """
        sum = 0.0
        mean = self.arithmeticMean()
        for item in self.data:
            sum = sum + (float(item) - float(mean)) ** 2
        return sum / float(len(self.data) - 1)
    
    def __str__(self):
        return str(self.summary)
        
    def fullSummary(self):
        self.summary['gMean'] = self.geometricMean()
        self.summary['hMean'] = self.harmonicMean()
        self.summary['aMean'] = self.arithmeticMean()
        self.summary['skew'] = self.skew()
        self.summary['kurtosis'] = self.kurtosis()
        self.summary['variance'] = self.variance()
        self.summary['stdev'] = self.summary['variance'] ** 0.5
        self.summary['variation'] = self.variation()
        self.summary['range'] = self.range()
        self.summary['median'] = nrpy.mdian1(self.data)