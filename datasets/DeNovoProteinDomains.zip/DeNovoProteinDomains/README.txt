De Novo Putative Protein Domains from Random Peptides

Maurice HT Ling (mauriceling@acm.org)

Procedure

    1. Ten thousand random peptide sequences of 267 amino acids each, which is the average peptide length [1], were generated as 5 sets of 2000 random peptides using RANDOMSEQ [2] with the following command, python randomseq.py FLS --length=267 --n=2000 --selection=A,825;R,553;N,406;D,545;C,137;Q,393;E,675;G,707;H,227;I,596;L,966;K,584;M,242;F,386;P,470;S,656;T,534;W,108;Y,292;V,687 --fasta=True, as Set{1-5}.fasta. Amino acid composition is based on average amino acid composition (https://web.expasy.org/protscale/pscale/A.A.Swiss-Prot.html) per 10 thousand amino acids as computed from Swiss-Prot.

    2a. Each randomly generated peptide was scanned using ScanProsite [3] with Release 2019_02 of 13-Feb-2019 (contains 1825 documentation entries, 1310 patterns, 1236 profiles and 1260 ProRule, totaling to 2548 unique motifs), including motifs with a high probability of occurrence and running the scan at high sensitivity.

    2b. Each randomly generated peptide was scanned using NCBI-CDD [4, 5] against CDD version 3.16 [superset of 30569 PSSMs (position-specific scoring matrices) including NCBI-curated domains and data imported from Pfam, SMART, COG, PRK, and TIGRFAMs] with expect value threshold of 0.01, using composition-corrected scoring, not filtered for low-complexity regions, and including retired sequences.

Summary of Findings

    1. Of the 10000 randomly generated peptides, 69 (0.69%) were reliably mapped (confidence level = 0) to 6 (0.24%) unique ProSite motifs; which are (a) bipartite nuclear localization signal (PS50079) involving in protein uptake by the nucleus, (b) Ig-like domain (PS50835) involving in binding various ligands, (c) FERM domain (PS50057) involving in localizing proteins to plasma membrane, (d) cyclic nucleotide-binding domain (PS50042) involving in binding cyclic nucleotides such as cAMP or cGMP, (e) phosphatidylinositol-specific phospholipase C profiles (PS50007) involving in eukaryotic signal transduction, and (f) Gamma-carboxyglutamic acid-rich domain (PS50998) involving in blood coagulation.

    2. A further 2697 (26.97%) randomly generated peptides mapped at low confidence (confidence level = -1) to 431 (16.92%) unique ProSite motifs.

    3. 109 (1.09%) of the 10000 randomly generated peptides were mapped to 102 (0.33%) unique PSSMs by NCBI-CDD. The most significant 5 hits by E-values are (a) succinylglutamate desuccinylase / sspartoacylase family (Accession cl27097, e-value = 1.61e-5) involving in arginine catabolism by the arginine succinyltransferase pathway, (b) btuF superfamily (Accession number cl28215, e-value = 5.63e-5) which is part of ATP-binding cassette transporters, (c) Type 1 periplasmic binding fold superfamily (Accession number cl10011, e-value = 6.37e-5) involving in various ligand binding including peptides, amino acids, and sugar molecules, (d) FRG domain (Accession number cl07460, e-value = 9.12e-5) which is functionally uncharacterized at this moment, and (e) CMAS superfamily (Accession number cl28102, e-value = 9.21e-5) involving in fatty acid metabolism.

References

    [1] Brocchieri L, Karlin S. 2005. Protein length in eukaryotic and prokaryotic proteomes. Nucleic Acids Research 33(10):3390-400. PubMed ID 15951512.

    [2] Ling MHT. 2018. RANDOMSEQ: Python Command‒line Random Sequence Generator. MOJ Proteomics & Bioinformatics 7(4):206‒208.

    [3] De Castro E, Sigrist CJA, Gattiker A, Bulliard V, Langendijk-Genevaux PS, Gasteiger E, Bairoch A, Hulo N. 2006
    ScanProsite: detection of PROSITE signature matches and ProRule-associated functional and structural residues in proteins.
    Nucleic Acids Research 34(Web Server issue):W362-5. PubMed ID 16845026.

    [4] Marchler-Bauer A, Bryant SH. 2004. CD-Search: protein domain annotations on the fly. Nucleic Acids Research 32(Web Server issue):W327-31. PubMed ID 15215404.

    [5] Marchler-Bauer A, Lu S, Anderson JB, Chitsaz F, Derbyshire MK, Deweese-Scott C, Fong JH, Geer LY, Geer RC, Gonzales NR, Gwadz M, Hurwitz DI, Jackson JD, Ke Z, Lanczycki CJ, Lu F, Marchler GH, Mullokandov M, Omelchenko MV, Robertson CL, Song JS, Thanki N, Yamashita RA, Zhang D, Zhang N, Zheng C, Bryant SH. 2011. CDD: a Conserved Domain Database for the functional annotation of proteins. Nucleic Acids Research 39(Database issue):D225-9. PubMed ID 21109532.