from brainopy import brainopy
import neuron_list
import adjacency

import os
try: os.remove("brain.db")
except: pass

cycles_to_run = 16
neurons = neuron_list.male_neurons
adjacency = adjacency.male_adjacency

b = brainopy("brain.db")
b.logging = False

# Step 1: Assign a hypothetical neurotransmitter X
neurotransmitters = {"X": "hypothetical neurotransmitter"}
b.addNeurotransmitters(neurotransmitters)

# Step 2: Load neurons
x = 1
neuron_IDs = []
common_sensory_neuron_state_IDs = []
for name in neurons:
    try:
        IDs = b.addNamedNeuron(name)
        neuron_IDs.append(IDs)
        #if name in neuron_list.common_sensory_neurons: common_sensory_neuron_state_IDs.append(IDs[3])
        #print("%i neurons added: %s" % (x, IDs))
    except:
        print("Error adding neuron: %s" % IDs)
    x = x + 1

# Step 3: Load adjacency - Neuron to neuron links
x = 1
NNlinkages = []
for neuron_pair in adjacency:
    try:
        IDs = b.stapleNeurons(neuron_pair[0], neuron_pair[1], "name") 
        NNlinkages.append(IDs)
        #print("%i neuron-neuron linked: %s" % (x, IDs))
    except:
        print("Error adding neuron-neuron link: %s --> %s" % (neuron_pair[0], neuron_pair[1]))
    x = x + 1    

# Step 4: Insert value to synapses - Mimicking flooding the brain with an exogenous neurotransmitter
inputSignal = {"X": 10.0}
for location in b.getIDs("synapse_state"):
    b.inputSignal(location, inputSignal, "synapse_state_ID")
    b.con.commit()

# Step 5: Run the neural network
neuronList = b.getIDs("neuron_body")
for cycle in range(1, cycles_to_run+1): 
    b.runBrain(neuronList)
    print("%i cycle(s) executed" % cycle)

# Step 6: Print out neurotransmitter values of neurons
for neuron_name in neuron_list.common_sensory_neurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Common Sensory,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.common_pharynx_neurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Common Pharynx,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.common_interneurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Common Interneuron,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.common_head_motor_neurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Common Head Motor,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.common_sublateral_motor_neurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Common Sublateral Motor,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.common_ventral_cord_motor_neurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Common Ventral Cord Motor,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.male_specific_head_neurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Male Specific Head,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.male_specific_sensory_neurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Male Specific Sensory,%s,%s" % (neuron_name, value["X"]))
    except: pass
for neuron_name in neuron_list.male_specific_interneurons:
    try:
        value = b.readNeurotransmitters(neuron_name, identifier_type="name")
        print("Male Specific Interneuron,%s,%s" % (neuron_name, value["X"]))
    except: pass
