import random
import math

PI = 3.14159265358979323846
PI2 = 6.2831853071795864769252867665590057683943387987502

def bico(n, k):
    """
    Binomial coefficient. Returns n!/(k!(n-k)!)
    Depend: factln, gammln
    @see: NRP 6.1
    
    @see: Ling, MHT. 2009. Compendium of Distributions, I: Beta, Binomial, 
    Chi-Square, F, Gamma, Geometric, Poisson, Student's t, and Uniform. 
    The Python Papers Source Codes 1:4

    @param n: total number of items
    @param k: required number of items
    @return: floating point number
    
    @status: Tested function
    @since: version 0.1
    """
    return math.floor(math.exp(factln(n) - factln(k) - factln(n-k)))

def factln(n):
    """
    Natural logarithm of factorial: ln(n!)
    @see: NRP 6.1
    
    @see: Ling, MHT. 2009. Compendium of Distributions, I: Beta, Binomial, Chi-
    Square, F, Gamma, Geometric, Poisson, Student's t, and Uniform. The Python 
    Papers Source Codes 1:4

    @param n: positive integer
    @return: natural logarithm of factorial of n
    """
    return gammln(n + 1.0)

def gammln(n):
    """
    Complete Gamma function.
    @see: NRP 6.1
    @see: http://mail.python.org/pipermail/python-list/2000-June/671838.html
    @see: Ling, MHT. 2009. Compendium of Distributions, I: Beta, Binomial, Chi-
    Square, F, Gamma, Geometric, Poisson, Student's t, and Uniform. The Python 
    Papers Source Codes 1:4

    @param n: float number
    @return: float number
    
    @status: Tested function
    @since: version 0.1
    """
    gammln_cof = [76.18009173, -86.50532033, 24.01409822,
                  -1.231739516e0, 0.120858003e-2, -0.536382e-5]
    x = n - 1.0
    tmp = x + 5.5
    tmp = (x + 0.5) * math.log(tmp) - tmp
    ser = 1.0
    for j in range(6):
        x = x + 1.
        ser = ser + gammln_cof[j] / x
    return tmp + math.log(2.50662827465 * ser)

class Distribution:
    """
    Abstract class for all statistical distributions.
    Due to the large variations of parameters for each distribution, 
    it is unlikely to be able to standardize a parameter list for each 
    method that is meaningful for all distributions. Instead, the 
    parameters to construct each distribution is to be given as 
    keyword arguments.
    """

    def __init__(self, **parameters):
        """
        Constructor method. The parameters are used to construct the
        probability distribution.
        """
        raise NotImplementedError

    def CDF(self, x):
        """
        Cumulative Distribution Function, which gives the cumulative
        probability (area under the probability curve) from -infinity 
        or 0 to a give x-value on the x-axis where y-axis is the 
        probability. CDF is also known as density function.
        """
        raise NotImplementedError

    def PDF(self, x):
        """
        Partial Distribution Function, which gives the probability for 
        The particular value of x, or the area under probability 
        distribution from x-h to x+h for continuous distribution.
        """
        raise NotImplementedError

    def inverseCDF(self, probability, start=0.0, step=0.01):
        """
        It does the reverse of CDF() method, it takes a probability 
        value and returns the corresponding value on the x-axis.
        """
        raise NotImplementedError

    def mean(self):
        """
        Gives the arithmetic mean of the sample.
        """
        raise NotImplementedError

    def mode(self):
        """
        Gives the mode of the sample, if closed-form is available.
        """
        raise NotImplementedError

    def kurtosis(self):
        """
        Gives the kurtosis of the sample.
        """
        raise NotImplementedError

    def skew(self):
        """
        Gives the skew of the sample.
        """
        raise NotImplementedError

    def variance(self):
        """
        Gives the variance of the sample.
        """
        raise NotImplementedError


class CauchyDistribution(Distribution):
    """
    Class for Cauchy Distribution.
    
    @status: Tested method
    @since: version 0.4
    """
    
    def __init__(self, location=0.0, scale=1.0): 
        """
        Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param location: the mean; default = 0.0
        @param scale: spread of the distribution, S{lambda}; default = 1.0
        """
        self.location = location
        self.scale = scale
    
    def CDF(self, x): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the probability curve) from -infinity or 
        0 to a give x-value on the x-axis where y-axis is the probability.
        """
        return 0.5 + 1 / PI * math.atan((x - self.location) / self.scale)
    
    def PDF(self, x): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x, or the area under probability distribution 
        from x-h to x+h for continuous distribution.
        """
        return 1 / (PI * self.scale * \
            (1 + (((x - self.location) / self.scale) ** 2)))
    
    def inverseCDF(self, probability, start=0.0, step=0.01): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis.
        """
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (start, cprob)
    
    def mean(self): 
        """Gives the arithmetic mean of the sample."""
        raise DistributionFunctionError('Mean for Cauchy Distribution is \
            undefined')
    
    def mode(self): 
        """Gives the mode of the sample."""
        return self.location
    
    def median(self): 
        """Gives the median of the sample."""
        return self.location
    
    def quantile1(self): 
        """Gives the 1st quantile of the sample."""
        return self.location - self.scale
    
    def quantile3(self): 
        """Gives the 3rd quantile of the sample."""
        return self.location + self.scale
    
    def qmode(self): 
        """Gives the quantile of the mode of the sample."""
        return 0.5
    
    def random(self, seed):
        """Gives a random number based on the distribution."""
        while 1:
            seed = self.loaction + (self.scale * \
                                    math.tan(PI * (seed - 0.5)))
            yield seed
        
        
class CosineDistribution(Distribution):
    """
    Cosine distribution is sometimes used as a simple approximation to 
    Normal distribution.
    
    @status: Tested method
    @since: version 0.4
    """
    
    def __init__(self, location=0.0, scale=1.0): 
        """
        Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param location: the mean; default = 0.0
        @param scale: spread of the distribution, S{lambda}; default = 1.0
        """
        self.location = location
        self.scale = scale
        
    def CDF(self, x): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the probability curve) from -infinity or 
        0 to a give x-value on the x-axis where y-axis is the probability.
        """
        n = PI + (x - self.location) / self.scale + \
            math.sin((x - self.location) / self.scale)
        return n / PI2
        
    def PDF(self, x): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x, or the area under probability distribution 
        from x-h to x+h for continuous distribution.
        """
        return (1 / (PI2 * self.scale)) * \
                (1 + math.cos((x - self.location) / self.scale))
                
    def inverseCDF(self, probability, start=0.0, step=0.01): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis.
        """
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (start, cprob)
        
    def mean(self): 
        """Gives the arithmetic mean of the sample."""
        return self.location
        
    def mode(self): 
        """Gives the mode of the sample."""
        return self.location
    
    def median(self): 
        """Gives the median of the sample."""
        return self.location
    
    def kurtosis(self): 
        """Gives the kurtosis of the sample."""
        return -0.5938
    
    def skew(self): 
        """Gives the skew of the sample."""
        return 0.0
    
    def variance(self): 
        """Gives the variance of the sample."""
        return (((PI * PI)/3) - 2) * (self.scale ** 2)
    
    def quantile1(self): 
        """Gives the 1st quantile of the sample."""
        return self.location - (0.8317 * self.scale)
    
    def quantile3(self): 
        """Gives the 13rd quantile of the sample."""
        return self.location + (0.8317 * self.scale)
    
    def qmean(self): 
        """Gives the quantile of the arithmetic mean of the sample."""
        return 0.5
    
    def qmode(self): 
        """Gives the quantile of the mode of the sample."""
        return 0.5


class ExponentialDistribution(Distribution):
    """
    Exponential distribution is the continuous version of Geometric 
    distribution. It is also a special case of Gamma distribution where 
    shape = 1
    
    @status: Tested method
    @since: version 0.4
    """
    
    def __init__(self, location=0.0, scale=1.0): 
        """
        Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param location: position of the distribution, default = 0.0
        @param scale: spread of the distribution, S{lambda}; default = 1.0
        """
        self.location = location
        self.scale = scale
    
    def CDF(self, x): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the probability curve) from -infinity or 
        0 to a give x-value on the x-axis where y-axis is the probability.
        """
        return 1 - math.exp((self.location - x) / self.scale)
    
    def PDF(self, x): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x, or the area under probability distribution 
        from x-h to x+h for continuous distribution.
        """
        return (1/self.scale) * math.exp((self.location - x)/self.scale)
    
    def inverseCDF(self, probability, start=0.0, step=0.01): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis.
        """
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (start, cprob)
    
    def mean(self): 
        """Gives the arithmetic mean of the sample."""
        return self.location + self.scale
    
    def mode(self): 
        """Gives the mode of the sample."""
        return self.location
    
    def median(self): 
        """Gives the median of the sample."""
        return self.location + (self.scale * math.log10(2))
    
    def kurtosis(self): 
        """Gives the kurtosis of the sample."""
        return 6.0
    
    def skew(self): 
        """Gives the skew of the sample."""
        return 2.0
    
    def variance(self): 
        """Gives the variance of the sample."""
        return self.scale * self.scale
    
    def quantile1(self): 
        """Gives the 1st quantile of the sample."""
        return self.location + (self.scale * math.log10(1.333))
    
    def quantile3(self): 
        """Gives the 3rd quantile of the sample."""
        return self.location + (self.scale * math.log10(4))
    
    def qmean(self): 
        """Gives the quantile of the arithmetic mean of the sample."""
        return 0.6321
    
    def qmode(self): 
        """Gives the quantile of the mode of the sample."""
        return 0.0
    
    def random(self):
        """Gives a random number based on the distribution."""
        return random.expovariate(1/self.location)


class HypergeometricDistribution(Distribution):
    """
    Class for Hypergeometric distribution
    
    @status: Tested method
    @since: version 0.4
    """
    
    def __init__(self, sample_size, 
                 population_size=100, 
                 population_success=50): 
        """
        Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param sample_size: sample size (not more than population size)
        @type sample_size: integer
        @param population_size: population size; default = 100
        @type population_size: integer
        @param population_success: number of successes in the population
        (cannot be more than population size); default = 10
        @type population_success: integer"""
        if population_success > population_size:
            raise AttributeError('population_success cannot be more \
            than population_size')
        elif sample_size > population_size:
            raise AttributeError('sample_size cannot be more \
            than population_size')
        else:
            self.psize = int(population_size)
            self.psuccess = int(population_success)
            self.ssize = int(sample_size)
            
    def CDF(self, sample_success): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the probability curve) from -infinity or 
        0 to a give x-value (sample_success, an integer that is not more 
        than sample size) on the x-axis where y-axis is the probability.
        """
        if sample_success > self.ssize:
            raise AttributeError('sample_success cannot be more \
            than sample_size')
        else:
            return sum([self.PDF(n) for n in range(1, sample_success+1)])
            
    def PDF(self, sample_success): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x (sample_success, an integer that is not more 
        than sample size), or the area under probability distribution from 
        x-h to x+h for continuous distribution."""
        if sample_success > self.ssize:
            raise AttributeError('sample_success cannot be more \
            than sample_size')
        else:
            sample_success = int(sample_success)
            numerator = bico(self.psuccess, sample_success)
            numerator = numerator  * bico(self.psize-self.psuccess, 
                                          self.ssize-sample_success)
            denominator = bico(self.psize, self.ssize)
            return float(numerator)/float(denominator)
            
    def inverseCDF(self, probability, start=1, step=1): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis."""
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (int(start), cprob)
        
    def mean(self): 
        """Gives the arithmetic mean of the sample."""
        return self.ssize * (float(self.psuccess)/float(self.psize))
        
    def mode(self): 
        """Gives the mode of the sample."""
        temp = (self.ssize + 1) * (self.psuccess + 1)
        return float(temp)/float(self.psize + 2)

    def variance(self): 
        """Gives the variance of the sample."""
        t1 = float(self.psize-self.psuccess)/float(self.psize)
        t2 = float(self.psize-self.ssize)/float(self.psize-1)
        return self.mean() * t1 * t2
    
    
class LogarithmicDistribution(Distribution):
    """
    Class for Logarithmic Distribution.
    
    @status: Tested method
    @since: version 0.4
    """
    
    def __init__(self, shape): 
        """Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param shape: the spread of the distribution"""
        self.shape = shape
    
    def CDF(self, x): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the probability curve) from -infinity or 
        0 to a give x-value on the x-axis where y-axis is the probability.
        """
        summation = 0.0
        for i in range(int(x)): summation = summation + self.PDF(i)
        return summation
    
    def PDF(self, x): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x, or the area under probability distribution 
        from x-h to x+h for continuous distribution.
        """
        return (-1 * (self.shape ** x)) / (math.log10(1 - self.shape) * x)
    
    def inverseCDF(self, probability, start=0.0, step=0.01): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis.
        """
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (start, cprob)
    
    def mean(self): 
        """Gives the arithmetic mean of the sample."""
        return (-1 * self.shape) / ((1 - self.shape) * \
                math.log10(1 - self.shape))
    
    def mode(self): 
        """Gives the mode of the sample."""
        return 1.0
    
    def variance(self): 
        """Gives the variance of the sample."""
        n = (-1 * self.shape) * (self.shape + math.log10(1 - self.shape))
        d = ((1 - self.shape) ** 2) * math.log10(1 - self.shape) * \
            math.log10(1 - self.shape)
        return n / d
    
    
class SemicircularDistribution(Distribution):
    """
    Class for Semicircular Distribution.
    
    @status: Tested method
    @since: version 0.4
    """
    
    def __init__(self, location=0.0, scale=1.0): 
        """
        Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param location: mean of the distribution, default = 0.0
        @param scale: spread of the distribution, default = 1.0"""
        self.location = location
        self.scale = scale
    
    def CDF(self, x): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the probability curve) from -infinity or 
        0 to a give x-value on the x-axis where y-axis is the probability.
        """
        t = (x - self.location) / self.scale
        return 0.5 + (1 / PI) * \
            (t * math.sqrt(1 - (t ** 2)) + math.asin(t))
    
    def PDF(self, x): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x, or the area under probability distribution 
        from x-h to x+h for continuous distribution.
        """
        return (2 / (self.scale * PI)) * \
                math.sqrt(1 - ((x - self.location) / self.scale) ** 2)
    
    def inverseCDF(self, probability, start=-10.0, step=0.01): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis.
        """
        if start < -1 * self.scale:
            start = -1 * self.scale
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (start, cprob)
    
    def mean(self): 
        """Gives the arithmetic mean of the sample."""
        return self.location
    
    def mode(self): 
        """Gives the mode of the sample."""
        return self.location
    
    def kurtosis(self): 
        """Gives the kurtosis of the sample."""
        return -1.0
    
    def skew(self): 
        """Gives the skew of the sample."""
        return 0.0
    
    def variance(self): 
        """Gives the variance of the sample."""
        return 0.25 * (self.scale ** 2)
    
    def quantile1(self): 
        """Gives the 1st quantile of the sample."""
        return self.location - (0.404 * self.scale)
    
    def quantile3(self): 
        """Gives the 3rd quantile of the sample."""
        return self.location + (0.404 * self.scale)
    
    def qmean(self): 
        """Gives the quantile of the arithmetic mean of the sample."""
        return 0.5
    
    def qmode(self): 
        """Gives the quantile of the mode of the sample."""
        return 0.5
    
    
class TriangularDistribution(Distribution):
    """
    Class for Triangular Distribution.
    
    @status: Tested method
    @since: version 0.4
    """
    def __init__(self, upper_limit, peak, lower_limit=0): 
        """
        Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param upper_limit: upper limit of the distrbution
        @type upper_limit: float
        @param peak: peak of the distrbution, which has to be between
        the lower and upper limits of the distribution
        @type peak: float
        @param lower_limit: lower limit of the distrbution,
        default = 0
        @type lower_limit: float"""
        self.lower_limit = lower_limit
        if upper_limit < self.lower_limit:
            raise AttributeError
        else:
            self.upper_limit = upper_limit
        if peak > upper_limit: 
            raise AttributeError
        if peak < lower_limit + 0.001:
            raise AttributeError
        else:
            self.mode = peak
            
    def CDF(self, x): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the probability curve) from -infinity or 
        0 to a give x-value on the x-axis where y-axis is the probability.
        """
        if x < self.lower_limit:
            raise AttributeError
        if x > self.mode:
            raise AttributeError
        else:
            return (( x - self.lower_limit) ** 2) / \
                ((self.upper_limit - self.lower_limit) * \
                 (self.mode - self.lower_limit))
                 
    def PDF(self, x): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x, or the area under probability distribution 
        from x-h to x+h for continuous distribution."""
        if x < self.lower_limit:
            raise AttributeError
        if x > self.mode:
            raise AttributeError
        else:
            return ((2 * (x - self.lower_limit)) / \
                    ((self.upper_limit - self.lower_limit) * \
                     (self.mode - self.lower_limit)))
                     
    def inverseCDF(self, probability, start=0, step=0.01): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis."""
        start = self.lower_limit
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (start, cprob)
        
    def mean(self): 
        """Gives the arithmetic mean of the sample."""
        return (float(self.lower_limit + self.upper_limit + self.mode) / 3)
        
    def mode(self): 
        """Gives the mode of the sample."""
        return (self.mode)
        
    def kurtosis(self): 
        """Gives the kurtosis of the sample."""
        return ((-3)*(5 ** - 1))
        
    def skew(self): 
        """Gives the skew of the sample."""
        return (math.sqrt(2) * \
                (self.lower_limit + self.upper_limit - 2 * self.mode) * \
                (2 * self.lower_limit - self.self.upper_limit - \
                 self.mode) * (self.lower_limit - 2 * \
                self.upper_limit + self.mode)) / \
                (self.lower_limit ** 2 + self.upper_limit ** 2 + \
                 self.mode ** 2 - self.lower_limit * self.upper_limit + \
                 self.mode ** 2 - self.lower_limit * \
                 (self.upper_limit - self.mode))
        
    def variance(self): 
        """Gives the variance of the sample."""
        return (self.lower_limit ** 2 + self.upper_limit ** 2 + \
                self.mode ** 2 - \
                (self.lower_limit * self.upper_limit) - \
                (self.lower_limit * self.mode) - \
                (self.upper_limit * self.mode)) * (18 ** -1)
        
    def quantile1(self): 
        """Gives the 1st quantile of the sample."""
        if ((self.mode - self.lower_limit) * \
        (self.upper_limit - self.lower_limit) ** -1) > 0.25:
            return self.lower_limit + \
                (0.5 * math.sqrt((self.upper_limit - \
                self.lower_limit) * (self.mode - self.lower_limit)))
        else:
            return self.upper_limit - \
                ((0.5) * math.sqrt (3 * (self.upper_limit -\
                self.lower_limit) * (self.upper_limit - self.mode)))
            
    def quantile3(self): 
        """Gives the 3rd quantile of the sample."""
        if ((self.mode - self.lower_limit) * \
        (self.upper_limit - self.lower_limit) ** -1) > 0.75:
            return self.lower_limit + \
                (0.5 * math.sqrt(3 * (self.upper_limit - \
                self.lower_limit) * (self.mode - self.lower_limit)))
        else:
            return self.upper_limit - \
                ((0.5) * math.sqrt ((self.upper_limit -\
                self.lower_limit) * (self.upper_limit - self.mode)))
            
    def qmean(self): 
        """Gives the quantile of the arithmetic mean of the sample."""
        if self.mode > ((self.lower_limit + self.upper_limit) * 0.5):
            return ((self.upper_limit + self.mode - 2 * \
                     self.lower_limit) ** 2) * (9 * \
                    (self.upper_limit - self.lower_limit) * \
                    (self.mode - self.lower_limit))
        else:
            return (self.lower_limit ** 2 + (5 * self.lower_limit * \
                    self.upper_limit) - (5 * (self.upper_limit ** 2)) - \
                    (7 * self.lower_limit * self.mode) + \
                    (5 * self. upper_limit * self.mode) + self.mode ** 2)
            
    def qmode(self): 
        """Gives the quantile of the mode of the sample."""
        return (self.mode - self.lower_limit) * (self.upper_limit \
        - self.lower_limit) ** - 1
        
    
class WeiBullDistribution(Distribution):
    """
    Class for Weibull distribution.
    
    @status: Tested method
    @since: version 0.4
    """
    def __init__(self, location=1.0, scale=1.0): 
        """Constructor method. The parameters are used to construct the 
        probability distribution.
        
        @param location: position of the distribution, default = 1.0
        @param scale: shape of the distribution, default = 1.0"""
        self.location = location
        self.scale = scale
        
    def CDF(self, x): 
        """
        Cumulative Distribution Function, which gives the cumulative 
        probability (area under the  probability curve) from -infinity 
        or 0 to a give x-value on the x-axis where y-axis is the 
        probability.
        """
        power = -1 * ((float(x) / self.location) ** self.scale)
        return 1 - (math.e ** power)
        
    def PDF(self, x): 
        """
        Partial Distribution Function, which gives the probability for the 
        particular value of x, or the area under probability distribution 
        from x-h to x+h for continuous distribution.
        """
        if x < 0:
            return 0
        else:
            power = -1 * ((float(x) / self.location) ** self.scale)
            t3 = math.e ** power
            t2 = (float(x) / self.location) ** (self.scale - 1)
            t1 = self.scale / self.location
            return t1 * t2 * t3
            
    def inverseCDF(self, probability, start=0.0, step=0.01): 
        """
        It does the reverse of CDF() method, it takes a probability value 
        and returns the corresponding value on the x-axis.
        """
        cprob = self.CDF(start)
        if probability < cprob: return (start, cprob)
        while (probability > cprob):
            start = start + step
            cprob = self.CDF(start)
            # print start, cprob
        return (start, cprob)
        
    def median(self): 
        """Gives the median of the sample."""
        return self.location * \
            (math.log(2, math.e) ** (1/float(self.scale)))
        
    def mode(self):
        """Gives the mode of the sample."""
        if self.scale > 1:
            t = ((self.scale - 1) / float(self.scale))
            return self.location * (t ** (1/float(self.scale)))
        else:
            return 0
            
    def random(self):
        """Gives a random number based on the distribution."""
        return random.weibullvariate(self.scale, self.shape)

        
def FrechetDistribution(**parameters):
    """
    Frechet distribution is an alias of Weibull distribution."""
    return WeibullDistribution(**parameters)
