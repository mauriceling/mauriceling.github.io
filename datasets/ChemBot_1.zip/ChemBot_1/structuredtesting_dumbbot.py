# -*- coding: utf-8 -*-
"""
Script to perform structured testing on DumbBot using 50 user questions
"""
import time

from chatterbot import ChatBot

try: os.remove("./dumbBot_chat.db")
except: pass

# Uncomment the following lines to enable verbose logging
#import logging
#logging.basicConfig(level=logging.INFO)

# Create a new instance of a ChatBot
bot = ChatBot(
    'DumbBot',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    logic_adapters=['chatterbot.logic.BestMatch'],
    database_uri='sqlite:///dumbBot_chat.db'
)

print('Type something to begin...')

user_questions = ['What is the electronic configuration of nitrogen?', 'What are the forces between ammonia?', 'Why do Protons only exist in the nucleus?', 'Why are ionic bonds the strongest bond?', 'What are orbitals?', 'How to calculate pH of a solution?', 'What are the bonds present in a covalent bonding?', 'What is hydrogen bonding?', 'Why do ionic compounds have a high boiling point?', 'Why are some acids strong and some are weak acid?', 'Why water have hydrogen bonding?', 'What is the classical method of naming compounds?', 'What is the equilibrium constant?', 'What is ionic equilibrium?', 'How to calculate molarity?', 'What are the different types of bonding forces?', 'What is a buffer solution?', 'How do I make a buffer soluton?', 'What is equilibrium?', 'How to find dilution factor?', 'How to calculate mol?', 'What is atomic mass?', 'What is atomic weight?', 'What is molecular weight?', 'What is formula weight?', 'How to calculate percentage composition?', "What is the Avogadro's number?", 'What is molar mass?', 'How do I find the number of moles?', 'What is stoichiometry?', 'What is a limiting reactant?', 'What is an excess reactant?', 'How to find precent yield?', 'What is a monoprotic acid?', 'What is amphoteric?', 'What is the unit of pH?', 'What do pH and pOH measure?', 'What happens when a strong acid and a base react?', 'What is a conjugate base and conjugate acid?', 'What is buffer capacity?', 'What is equivalence point?', 'What is chemical kinetics?', 'What is activation energy?', 'What does a catalyst do?', 'How does the temperature affect the reaction rate?', 'What is a reversible reaction?', 'What is a dynamic equilibrium?', "What is Le Chatelier's principle?", 'Why does the equilibrium shifts?', 'What is a weak acid?']

# The following loop will execute each time the user enters input
i = 1
for user_input in user_questions:
    bot_response = bot.get_response(user_input)
    print("User question %s: %s" % (str(i), user_input))
    print("DumbBot: " + str(bot_response))
    time.sleep(1.2)
    i = i + 1