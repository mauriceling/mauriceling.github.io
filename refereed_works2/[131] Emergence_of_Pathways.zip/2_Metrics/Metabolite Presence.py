import sqlite3
import pandas as pd

conn = sqlite3.connect('C:/Users/User/OneDrive/Documents/GitHub/dose/Simulations/largecells.db')  

query = "select * from organisms where key='blood' and generation;"
df_org = pd.read_sql_query(query, conn)
conn.close()

df= df_org.copy()
print(df.columns)
df_presence = pd.DataFrame(df[['generation']])

value_list = df['value'].tolist()
val_split_list = split_list = [item.split('|') for item in value_list]

met_present = []
for genrep in val_split_list:
    met_present.append(sum([1 for metabolite in genrep if float(metabolite) > 0]))
df_presence['met_present'] = met_present


df_presence['generation'] = df_presence['generation'].astype('int')
df_presence = df_presence.sort_values(by='generation')
df_presence = df_presence.reset_index(drop=True)

df_presence.to_excel('C:\FYP\MetaboliteSum_met_presence.xlsx',index=False)


