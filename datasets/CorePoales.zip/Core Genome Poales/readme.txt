1. Poales.zip file is the dehydrated zip file of sequences from NCBI Datasets (https://www.ncbi.nlm.nih.gov/datasets/), which must be unzipped into a folder and rehydrated using dataset tool with the following command: datasets rehydrate --directory <poales folder>.

2. Pairwise Threshold.xlsx contains results of the 9 pairwise comparisons in Table 2 of the manuscript.

3. BLAST Results.xlsx contains the blastn results of progressive genome intersection (data for Tables 3 and 4 of the manuscript).

4. IntersectionListing folder contains the intermediate core genome listing (data of Table 3 of manuscript).

5. PoalesCoreGenome.fasta is the 6,122 gene core genome, which is essentially P1P2P3P4P5P6P7P8P9P10.

6. CoreGenomeMaize.csv contains the gene IDs of the 6,122 genes in Z. mays gene IDs.

7. Functional Classification.xlsx contains results of functional classification (data of Figures 1 and 2 of manuscript).