datasets = [("hermaphrodite", "adjacency_hermaphrodite_chemical.csv"), 
            ("male", "adjacency_male_chemical.csv")]

for dataset in datasets:
    adjacency = open(dataset[1], "r").readlines()
    adjacency = [x[:-1].split(",") for x in adjacency]
    adjacency = [[x.strip() for x in row] for row in adjacency]
    post_neuron = adjacency[0]
    post_neuron = post_neuron[1:]
    adjacency = adjacency[1:]
    d = {}
    for x in adjacency: d[x[0]] = x[1:]
    connections = []
    for pre_neuron in d:
        for i in range(len(d[pre_neuron])):
            if d[pre_neuron][i] != "": connections.append([pre_neuron, post_neuron[i]])
    neurons = [adj[0] for adj in connections] + [adj[1] for adj in connections]
    neurons = list(set(neurons))
    print("%s_neurons = %s" % (dataset[0], neurons))
    print("")
    print("%s_adjacency = %s" % (dataset[0], connections))
    print("")