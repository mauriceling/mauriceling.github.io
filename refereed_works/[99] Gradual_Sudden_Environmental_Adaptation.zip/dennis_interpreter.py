'''
Dennis Genomic Interpreter
Date created: 25th January 2021

The interpreter environment consists of the following elements:

    1. Array/Tape: A circular tape initialized with 25 cells representing 
    25 metabolites.
    2. Source: The program, representing the genome
    3. Input List: A list of data given to the execution environment at 
    initialization.
    4. Output List: A list of output from the execution. This may also be 
    used as a secondary tape. 

When the program terminates, 4 elements (Array, Source, Input List and 
Output List) are returned, and the interpreter terminates itself. 
'''
codonLength = 2


def interpret_codon(array, apointer, inputdata, output, source, spointer):
    '''
    R1:  1   +   24  =>   4   +   22
    R2:  2   +   16  =>   17  +   3
    R3:  2   +   3   =>   13  +   6
    R4:  2   +   22  =>   18  +   11
    R5:  2   +   20  =>   6   +   12
    R6:  2   +   21  =>   4   +   15
    R7:  2   +   1   =>   12  +   23
    R8:  5   +   15  =>   4   +   1
    R9:  6   +   12  =>   13  +   10
    R10: 9   +   18  =>   4   +   12
    R11: 10  +   3   =>   22  +   11
    R12: 10  +   5   =>   6   +   12
    R13: 10  +   11  =>   4   +   22
    R14: 11  +   12  =>   4   +   13
    R15: 11  +   7   =>   9   +   13
    R16: 12  +   18  =>   7   +   19
    R17: 12  +   8   =>   0   +   22
    R18: 14  +   17  =>   22  +   5
    R19: 14  +   8   =>   9   +   12
    R20: 14  +   2   =>   23  +   24
    R21: 16  +   7   =>   9   +   12
    R22: 17  +   23  =>   4   +   24
    R23: 18  +   23  =>   10  +   1
    R24: 19  +   5   =>   23  +   0
    R25: 19  +   20  =>   4   +   10
    R26: 20  +   6   =>   9   +   1
    R27: 20  +   5   =>   17  +   12
    R28: 12  +   18  =>   4   +   17
    R29: 21  +   10  =>   18  +   5
    R30: 21  +   23  =>   4   +   5
    R31: 22  +   17  =>   9   +   18
    R32: 22  +   1   =>   24  +   20
    R33: 24  +   16  =>   15  +   0
    R34: 24  +   15  =>   1   +   13
    R35: 24  +   5   =>   1   +   17
    R36: eO2 =>  14 + eO2
    R37: eC => 2 + eC
    '''
    cmd = source[spointer:spointer+codonLength]
    if cmd == '01': array[4], array[22] = array[1] + array[24], array[1] + array[24]
    if cmd == '02': array[17], array[3] = array[2] + array[16], array[2] + array[16]
    if cmd == '03': array[13], array[6] = array[2] + array[3], array[2] + array[3]
    if cmd == '04': array[18], array[11] = array[2] + array[22], array[2] + array[22]
    if cmd == '05': array[6], array[12] = array[2] + array[20], array[2] + array[20]
    if cmd == '06': array[4], array[15] = array[2] + array[21], array[2] + array[21]
    if cmd == '07': array[12], array[23] = array[2] + array[1], array[2] + array[1]
    if cmd == '08': array[4], array[1] = array[5] + array[15], array[5] + array[15]
    if cmd == '09': array[13], array[10] = array[6] + array[12], array[6] + array[12]
    if cmd == '10': array[4], array[12] = array[9] + array[18], array[9] + array[18]
    if cmd == '11': array[22], array[11] = array[10] + array[3], array[10] + array[3]
    if cmd == '12': array[6], array[12] = array[6] + array[12], array[6] + array[12]
    if cmd == '13': array[4], array[22] = array[10] + array[11], array[10] + array[11]
    if cmd == '14': array[4], array[13] = array[11] + array[12], array[11] + array[12]
    if cmd == '15': array[9], array[13] = array[11] + array[7], array[11] + array[7]
    if cmd == '16': array[7], array[19] = array[12] + array[18], array[12] + array[18]
    if cmd == '17': array[0], array[22] = array[12] + array[8], array[12] + array[8]
    if cmd == '18': array[22], array[5] = array[14] + array[17], array[14] + array[17]
    if cmd == '19': array[9], array[12] = array[14] + array[8], array[14] + array[8]
    if cmd == '20': array[23], array[24] = array[14] + array[2], array[14] + array[2]
    if cmd == '21': array[9], array[12] = array[16] + array[7], array[16] + array[7]
    if cmd == '22': array[4], array[24] = array[17] + array[23], array[17] + array[23]
    if cmd == '23': array[10], array[1] = array[18] + array[23], array[18] + array[23]
    if cmd == '24': array[23], array[0] = array[19] + array[5], array[19] + array[5]
    if cmd == '25': array[4], array[10] = array[19] + array[20], array[19] + array[20]
    if cmd == '26': array[9], array[1] = array[20] + array[6], array[20] + array[6]
    if cmd == '27': array[17], array[12] = array[20] + array[5], array[20] + array[5]
    if cmd == '28': array[4], array[17] = array[12] + array[18], array[12] + array[18]
    if cmd == '29': array[18], array[5] = array[21] + array[10], array[21] + array[10]
    if cmd == '30': array[4], array[5] = array[21] + array[23], array[21] + array[23]
    if cmd == '31': array[9], array[18] = array[22] + array[17], array[22] + array[17]
    if cmd == '32': array[24], array[20] = array[22] + array[1], array[22] + array[1]
    if cmd == '33': array[15], array[0] = array[24] + array[16], array[24] + array[16]
    if cmd == '34': array[1], array[13] = array[24] + array[15], array[24] + array[15]
    if cmd == '35': array[1], array[17] = array[24] + array[5], array[24] + array[5]
    if cmd == '36': array[14] = array[14] + inputdata[0]
    if cmd == '37': array[2] = array[2] + inputdata[1]
    return (array, apointer, inputdata, output, source, spointer)

interpreter = {'01': interpret_codon, '02': interpret_codon,
               '03': interpret_codon, '04': interpret_codon, 
               '05': interpret_codon, '06': interpret_codon, 
               '07': interpret_codon, '08': interpret_codon, 
               '09': interpret_codon, '10': interpret_codon, 
               '11': interpret_codon, '12': interpret_codon, 
               '13': interpret_codon, '14': interpret_codon, 
               '15': interpret_codon, '16': interpret_codon, 
               '17': interpret_codon, '18': interpret_codon, 
               '19': interpret_codon, '20': interpret_codon, 
               '21': interpret_codon, '22': interpret_codon, 
               '23': interpret_codon, '24': interpret_codon, 
               '25': interpret_codon, '26': interpret_codon, 
               '27': interpret_codon, '28': interpret_codon, 
               '29': interpret_codon, '30': interpret_codon, 
               '31': interpret_codon, '32': interpret_codon, 
               '33': interpret_codon, '34': interpret_codon, 
               '35': interpret_codon, '36': interpret_codon,
               '37': interpret_codon}
