import sys
import subprocess
import os

library_list = [["qary", "0.6.22"], ["opsdroid", "0.20.2"], 
                ["iokobot", "0.6"], ["chatbot-creator", "0.0.5"], 
                ["agt", "0.6.1"], ["msgflow", "0.6.0"],
                ["Bani", "0.6.3"], ["deeppavlov", "0.14.0"], 
                ["cobe", "3.0.1"], ["chatbotAI", "0.3.0.0"], 
                ["commandintegrator", "1.3.0"], ["minette", "0.4.3"], 
                ["chatbotmaker", "0.0.13"], ["ChatterBot", "1.0.8"], 
                ["jigbot", "0.1.1"], ["coco-puppet", "0.4.3"], 
                ["deeppavlov-agent", "2.2.0"], ["emora-stdm", "1.95"], 
                ["TChatBot", "0.1.0"], ["flipgenic", "0.5.0"], 
                ["dazu", "0.1.0"]]

subprocess.run("conda env remove --name baseline" , shell=True, text=True, input="y")

for lib in library_list:
    subprocess.run("conda env remove --name " + lib[0], shell=True, text=True, input="y")