# needed to run this example without prior
# installation of DOSE into Python site-packages
try: 
    import run_examples_without_installation
except ImportError: pass

# Example codes starts from here
import copy
import random
import dose

import dennis_interpreter


parameters = {# Part 1: Simulation metadata
              "simulation_name": "control_simulation",
              "population_names": ['pop_01'],

              # Part 2: World settings
              "world_x": 3,
              "world_y": 3,
              "world_z": 1,
              "population_locations": [[(0,0,0)]],
              "eco_cell_capacity": 100,
              "deployment_code": 1,

              # Part 3: Population settings
              "population_size": 100,

              # Part 4: Genetics settings
              "genome_size": 1,
              "chromosome_size": 370,
              "chromosome_bases": ['01', '02', '03', '04', '05', 
                                   '06', '07', '08', '09', '10',
                                   '11', '12', '13', '14', '15',
                                   '16', '17', '18', '19', '20',
                                   '21', '22', '23', '24', '25',
                                   '26', '27', '28', '29', '30',
                                   '31', '32', '33', '34', '35',
                                   '36', '37'],
              "initial_chromosome": ['01', '02', '03', '04', '05', 
                                   '06', '07', '08', '09', '10',
                                   '11', '12', '13', '14', '15',
                                   '16', '17', '18', '19', '20',
                                   '21', '22', '23', '24', '25',
                                   '26', '27', '28', '29', '30',
                                   '31', '32', '33', '34', '35',
                                   '36', '37'] * 10,

              # Part 5: Mutation settings
              "background_mutation": 0.01,
              "additional_mutation": 0,
              "mutation_type": 'point',
              
              # Part 6: Metabolic settings
              "interpreter": dennis_interpreter.interpreter,
              "instruction_size": 2,
              "ragaraja_version": "user-defined",
              "base_converter": None,
              "ragaraja_instructions": [],
              "max_tape_length": 25,
              "interpret_chromosome": True,
              "clean_cell": True,
              "max_codon": 2000,

              # Part 7: Simulation settings
              "goal": 0,
              "maximum_generations": 900,
              "eco_buried_frequency": 100,
              "fossilized_ratio": 0.01,
              "fossilized_frequency": 20,
              
              # Part 8: Simulation report settings
              "print_frequency": 10,
              "database_file": "simulation.db",
              "database_logging_frequency": 1
             }

class simulation_functions(dose.dose_functions):

    def organism_movement(self, Populations, pop_name, World): pass

    def organism_location(self, Populations, pop_name, World): pass

    def ecoregulate(self, World): pass

    def update_ecology(self, World, x, y, z): pass

    def update_local(self, World, x, y, z): pass

    def report(self, World): pass

    def fitness(self, Populations, pop_name): 
        for organism in Populations[pop_name].agents:
            organism.status['fitness'] = organism.status['blood'][4]

    def mutation_scheme(self, organism): 
        organism.genome[0].rmutate(parameters["mutation_type"],
                                   parameters["additional_mutation"])

    def prepopulation_control(self, Populations, pop_name):
        agents = Populations[pop_name].agents
        status = [(index, agents[index].status['fitness'])
                   for index in range(len(agents))]
        eliminate = [x[1] for x in status]
        eliminate.sort()
        ethreshold = eliminate[9]
        if len([x for x in eliminate if x > ethreshold]) < 50:
            eliminate = [x[0] for x in status]
            eliminate = [random.choice(eliminate) for x in range(10)]
            Populations[pop_name].agents = \
                [agents[i] for i in range(len(agents))
                    if i not in eliminate]
        print("Population size after elimination: " + \
            str(len(Populations[pop_name].agents)))

    def mating(self, Populations, pop_name): 
        agents = Populations[pop_name].agents
        while len(agents) < 100:
            chosen_agent = random.choice(agents)
            new_agent = copy.deepcopy(chosen_agent)
            new_agent.status['parents'] = new_agent.status['identity']
            new_agent.generate_name()
            agents.append(new_agent)

    def postpopulation_control(self, Populations, pop_name): pass

    def generation_events(self, Populations, pop_name): 
        agents = Populations[pop_name].agents
        gen_count = agents[0].status["generation"]
        if gen_count >= 100:
            print("Generation 100: Oxygen from 21% to 18%")
            dose.load_all_local_input(World, [18, 10])
            #print(World.ecosystem)
        if gen_count >= 200:
            print("Generation 200: Oxygen from 18% to 15%")
            dose.load_all_local_input(World, [15, 10])
            #print(World.ecosystem)
        if gen_count >= 300:
            print("Generation 300: Oxygen from 15% to 12%")
            dose.load_all_local_input(World, [12, 10])
            #print(World.ecosystem)
        if gen_count >= 400:
            print("Generation 400: Oxygen from 12% to 9%")
            dose.load_all_local_input(World, [9, 10])
            #print(World.ecosystem)
        if gen_count >= 500:
            print("Generation 500: Oxygen from 9% to 6%")
            dose.load_all_local_input(World, [6, 10])
            #print(World.ecosystem)
        if gen_count >= 600:
            print("Generation 600: Oxygen from 6% to 3%")
            dose.load_all_local_input(World, [3, 10])
            #print(World.ecosystem)
        if gen_count >= 700:
            print("Generation 700: Oxygen from 3% to 0%")
            dose.load_all_local_input(World, [0, 10])
            #print(World.ecosystem)
        if gen_count >= 800:
            print("Generation 800: Oxygen from 0% to 21%")
            dose.load_all_local_input(World, [21, 10])
            #print(World.ecosystem)

    def population_report(self, Populations, pop_name):
        for org in Populations[pop_name].agents:
            sequences = ','.join(org.genome[0].sequence)
            if org.status['parents'] == None: parent = "Ancestor"
            else: parent = org.status['parents']
            identity = org.status['identity']
            generation = org.status['generation']
            #locations = str(org.status['location'])
            #demes = org.status['deme']
            blood = org.status['blood']
            data = [str(generation), str(parent), str(identity), str(blood[4]), sequences]
            print(",".join(data))
        
        return '\n'.join(sequences)

    def database_report(self, con, cur, start_time, 
                        Populations, World, generation_count):
        try:
            dose.database_report_populations(con, cur, start_time, 
                                             Populations, generation_count)
        except: pass
        try:
            dose.database_report_world(con, cur, start_time, 
                                       World, generation_count)
        except: pass

    def deployment_scheme(self, Populations, pop_name, World): pass

print('\n[' + parameters["simulation_name"].upper() + ' SIMULATION]')
print('Adding deployment scheme to simulation parameters...')
parameters["deployment_scheme"] = simulation_functions.deployment_scheme
print('Constructing World entity...')
World = dose.dose_world.World(parameters["world_x"],
                         parameters["world_y"],
                         parameters["world_z"])
dose.load_all_local_input(World, [21, 10]) # [oxygen, carbon]
print(World.ecosystem)

print('Spawning populations...')
Populations = dose.spawn_populations(parameters)
print('\nStarting simulation on sequential ecological cell simulator...')
(simulation_functions, parameters, Populations, World) = \
    dose.sequential_simulator(simulation_functions, parameters, 
                              Populations, World)
print('\nSimulation ended...')

