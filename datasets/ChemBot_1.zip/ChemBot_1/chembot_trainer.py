# -*- coding: utf-8 -*-
"""
Script to train ChemBot with corpus
"""

from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

bot = ChatBot(
    'ChemBot',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    logic_adapters=['chatterbot.logic.BestMatch'],
    database_uri='sqlite:///chemBot_220712.db'
)

trainer = ChatterBotCorpusTrainer(bot)
trainer.train("./PIPC1_corpus_220712.yml")