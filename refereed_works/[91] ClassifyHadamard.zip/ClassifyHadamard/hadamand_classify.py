import pandas as pd
from scipy.linalg import hadamard
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics
from sklearn.model_selection import cross_val_score

n = 10
cvfold = 10
replicate = 10
column_ratios = [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]

def scoring(clf, method, i, X, Y):
    scores = cross_val_score(clf, X, Y, cv=cvfold, scoring="accuracy")
    (r, c) = X.shape
    outD = [method, str(r), str(c), str(i), str(clf.score(X, Y)), 
            str('%.7f' % scores.mean()), str('%.7f' % scores.std())]
    print(','.join(outD))

header = ['Method', '#Rows', '#Columns', 'Replicate', 
          'Score', '10CV-Mean', '10CV-Sigma']
print(','.join(header))

def selection(data, column):
    selection = data.sample(int(data.shape[1]*column), axis=1)
    label = list(selection.sample(1, axis=1))[0]
    Y = selection[label]
    X = selection.drop(label, axis=1)
    return (X, Y)

data = pd.DataFrame(data=hadamard(2**n))
for column in column_ratios:
    for i in range(replicate):
        (X, Y) = selection(data, column)
        # Logistic Regression
        clf = LogisticRegression()
        clf.fit(X, Y)
        scoring(clf, 'LogisticRegression', i+1, X, Y)
        # Support Vector Machine
        clf = SVC().fit(X, Y)
        scoring(clf, 'SupportVectorClassifier', i+1, X, Y)
        # Decision Tree Classifier
        clf = DecisionTreeClassifier().fit(X, Y)
        scoring(clf, 'DecisionTree', i+1, X, Y)
        # Multi-Layer Perceptron
        clf = MLPClassifier().fit(X, Y)
        scoring(clf, 'MultilayerPerceptron', i+1, X, Y)
