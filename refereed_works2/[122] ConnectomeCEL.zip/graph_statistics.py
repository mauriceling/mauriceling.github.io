import networkx as nx
import adjacency
import neuron_list

m = nx.DiGraph()
h = nx.DiGraph()

m.add_edges_from(adjacency.male_adjacency)
h.add_edges_from(adjacency.hermaphrodite_adjacency)

male_path_length = []
for s in neuron_list.common_sensory_neurons:
    for t in neuron_list.common_head_motor_neurons:
        try: 
            path_length = len(nx.shortest_path(m, source=s, target=t))
            male_path_length.append(str(path_length))
        except: pass
male_path_length = ','.join(male_path_length)
print("Male Path Lengths: %s" % male_path_length)

hermaphrodite_path_length = []
for s in neuron_list.common_sensory_neurons:
    for t in neuron_list.common_head_motor_neurons:
        try: 
            path_length = len(nx.shortest_path(h, source=s, target=t))
            hermaphrodite_path_length.append(str(path_length))
        except: pass
hermaphrodite_path_length = ','.join(hermaphrodite_path_length)
print("Hermaphrodite Path Lengths: %s" % hermaphrodite_path_length)
