1. PIPC1_corpus_220712.yml is the chemistry conversation corpus of near to 1000 questions and answers.

2. chembot_trainer.py is the Python script used to train DumbBot into ChemBot_1 by generating the trained conversation database, chemBot_220712.db.

3. chemBot_220712.db is the database representing a trained chatbot, which is ChemBot_1.

4. chembot.py is the Python script to run ChemBot_1.

5. dumbbot.py is the Python script to run DumbBot.

6. structuredtesting_chembot.py is the testing script to feed 50 test questions to ChemBot_1 to generate responses.

7. structuredtesting_chembot_responses.txt is the responses generated from structuredtesting_chembot.py.

8. structuredtesting_dumbbot.py is the testing script to feed 50 test questions to DumbBot to generate responses.

9. structuredtesting_dumbbot_responses.txt is the responses generated from structuredtesting_dumbbot.py.

10. ChemBot_v1 vs DumbBot.xlsx is the Excel file consisting of analysis of structuredtesting_chembot_responses.txt and structuredtesting_dumbbot_responses.txt.

11. Video for Comparative Testing of ChemBot_1 and DumbBot: https://youtu.be/tEJVRFphtLE