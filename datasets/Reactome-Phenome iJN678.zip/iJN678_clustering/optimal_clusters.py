from sklearn.cluster import KMeans
from sklearn.metrics import davies_bouldin_score
from sklearn.metrics import calinski_harabasz_score
from sklearn.metrics import silhouette_score
import pandas as pd

df = pd.read_excel("iJN678_fluxes.xlsx", sheet_name="iJN678", usecols="B:AGG", engine="openpyxl")
df = df.T     # columns are features, rows are samples

print("Clusters, Davies-Bouldin Score, Calinski and Harabasz Score, Silhouette Score")
for centre in range(2, 200):
    kmeans = KMeans(n_clusters=centre)
    model = kmeans.fit_predict(df)
    scores = [str(davies_bouldin_score(df, model)),
              str(calinski_harabasz_score(df, model)),
              str(silhouette_score(df, model))]
    print(centre, ",", ",".join(scores))
