import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Read excel file
df = pd.read_excel("C:\FYP\Control_diversity.xlsx")
df1 = pd.read_excel("C:\FYP\MetaboliteSum_diversity.xlsx")
df2 = pd.read_excel("C:\FYP\MetaboliteAverage_diversity.xlsx")
df3 = pd.read_excel("C:\FYP\MetaboliteUnique_diversity.xlsx")

#PLOT
sns.lineplot(data=df, x='Generation', y='DO_Mean', label='Control', errorbar='se', err_style='bars')
sns.lineplot(data=df1, x='Generation', y='DO_Mean', label='Metabolite Sum', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)
sns.lineplot(data=df2, x='Generation', y='DO_Mean', label='Metabolite Average', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)
sns.lineplot(data=df3, x='Generation', y='DO_Mean', label='Metabolite Unique', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)

plt.title("Grand mean of diversity across 1000 generations")
plt.xlabel('Generation')
plt.ylabel('Grand mean of diversity')
plt.xticks([100,200,300,400,500,600,700,800,900,1000])

plt.show()