import pandas as pd
from sklearn.cluster import KMeans
from yellowbrick.cluster import KElbowVisualizer

df = pd.read_excel("iJN678_fluxes.xlsx", sheet_name="iJN678", usecols="B:AGG", engine='openpyxl')
df = df.T       # columns are features, rows are samples
model_elbow = KMeans()
visualizer = KElbowVisualizer(model_elbow, k=(4,40), timings=False)
visualizer.fit(df)        # Fit the data to the visualizer
visualizer.show()        # Finalize and render the figure

model_Elbow = KMeans(n_clusters=11, random_state=0).fit(df) # optimal clusters from Elbow
model_Silhouette = KMeans(n_clusters=29, random_state=0).fit(df) # optimal clusters from Silhouette
model_DaviesBouldin = KMeans(n_clusters=35, random_state=0).fit(df) # optimal clusters from Davies-Bouldin

df["Elbow"] = model_Elbow.labels_
df["Silhouette"] = model_Silhouette.labels_
df["Davies-Bouldin"] = model_DaviesBouldin.labels_

df.to_csv("iJN678_clusterlabels.csv")