# needed to run this example without prior
# installation of DOSE into Python site-packages
try: 
    import run_examples_without_installation
except ImportError: pass

# Example codes starts from here
import copy
import os
import random
import sys

import dose
from dose_interpreters import D2_plus

environmental_data = [1000, # metabolite A / 0 (importer)
                      1000, # metabolite B / 1
                      1000, # metabolite C / 2 (importer)
                      1000, # metabolite D / 3
                      1000, # metabolite E / 4 (importer)
                      1000, # metabolite F / 5
                      1000, # metabolite G / 6 (importer)
                      1000, # metabolite H / 7
                      1000, # metabolite I / 8 (importer)
                      1000, # metabolite J / 9
                      1000, # metabolite K / 10 (importer)
                      1000, # metabolite L / 11
                      1000, # metabolite M / 12 (importer)
                      1000, # metabolite N / 13
                      1000, # metabolite O / 14 (importer)
                      1000, # metabolite P / 15
                      1000, # metabolite Q / 16 (importer)
                      1000, # metabolite R / 17
                      1000, # metabolite S / 18 (importer)
                      1000, # metabolite T / 19
                      1000, # metabolite U / 20 (importer)
                      1000, # metabolite V / 21
                      1000, # metabolite W / 22 (importer)
                      1000, # metabolite X / 23
                      1000  # metabolite Y / 24 (importer)
                     ]

parameters = {# Part 1: Simulation metadata
              "simulation_name": "uniquemetabolites",
              "population_names": ['pop_01'],

              # Part 2: World settings
              "world_x": 3,
              "world_y": 3,
              "world_z": 1,
              "population_locations": [[(0,0,0)]],
              "eco_cell_capacity": 100,
              "deployment_code": 1,

              # Part 3: Population settings
              "population_size": 100,

              # Part 4: Genetics settings
              "genome_size": 1,
              "chromosome_size": 2000,
              "chromosome_bases": ['0', '1', '2', '3', '4', 
                                   '5', '6', '7', '8', '9'],
              "initial_chromosome": ['0'] * 2000,

              # Part 5: Mutation settings
              "background_mutation": 0.01,
              "additional_mutation": 0,
              "mutation_type": 'point',
              
              # Part 6: Metabolic settings
              "interpreter": D2_plus.interpreter,
              "instruction_size": 2,
              "ragaraja_version": "user-defined",
              "base_converter": None,
              "ragaraja_instructions": [],
              "max_tape_length": 25,
              "interpret_chromosome": True,
              "clean_cell": True,
              "max_codon": 2000,

              # Part 7: Simulation settings
              "goal": 0,
              "maximum_generations": 1000,
              "eco_buried_frequency": 100,
              "fossilized_ratio": 0.01,
              "fossilized_frequency": 20,
              
              # Part 8: Simulation report settings
              "print_frequency": 50,
              "database_file": "uniquemetabolites.db",
              "database_logging_frequency": 50
             }

class simulation_functions(dose.dose_functions):

    def organism_movement(self, Populations, pop_name, World): pass

    def organism_location(self, Populations, pop_name, World): pass

    def ecoregulate(self, World): pass

    def update_ecology(self, World, x, y, z): pass

    def update_local(self, World, x, y, z): pass

    def report(self, World): pass

    def fitness(self, Populations, pop_name): 
        for organism in Populations[pop_name].agents:
            blood = organism.status['blood']
            met_present =  [1 for metabolite in blood if float(metabolite) > 0]
            organism.status['fitness'] = sum(met_present)

    def mutation_scheme(self, organism): 
        organism.genome[0].rmutate(parameters["mutation_type"],
                                   parameters["additional_mutation"])

    """
    def prepopulation_control(self, Populations, pop_name):
        agents = Populations[pop_name].agents
        status = [(index, agents[index].status['fitness'])
                   for index in range(len(agents))]
        eliminate = [x[1] for x in status]
        eliminate.sort()
        ethreshold = eliminate[9]
        if len([x for x in eliminate if x > ethreshold]) < 50:
            eliminate = [x[0] for x in status]
            eliminate = [random.choice(eliminate) for x in range(10)]
            Populations[pop_name].agents = \
                [agents[i] for i in range(len(agents))
                    if i not in eliminate]
        print("Population size after elimination: " + \
            str(len(Populations[pop_name].agents)))
      """

    def prepopulation_control(self, Populations, pop_name): 
        agents = Populations[pop_name].agents
        status = [(index, agents[index].status['fitness'])
                   for index in range(len(agents))]
        fitnessList = [x[1] for x in status]
        fitnessList.sort()
        threshold = fitnessList[9]
        if len([x for x in fitnessList if x > threshold]) > 50:
            Populations[pop_name].agents = \
                [agents[i] for i in range(len(agents))
                    if agents[i].status['fitness'] > threshold]
        else:
            agentIndex = [x[0] for x in status]
            eliminate = [random.choice(agentIndex) for x in range(10)]
            Populations[pop_name].agents = \
                [agents[i] for i in range(len(agents))
                    if i not in eliminate]
        print("Population size after elimination: " + \
            str(len(Populations[pop_name].agents)))


    def mating(self, Populations, pop_name): 
        agents = Populations[pop_name].agents
        while len(agents) < 100:
            chosen_agent = random.choice(agents)
            new_agent = copy.deepcopy(chosen_agent)
            new_agent.status['parents'] = new_agent.status['identity']
            new_agent.generate_name()
            agents.append(new_agent)

    def postpopulation_control(self, Populations, pop_name): pass

    def generation_events(self, Populations, pop_name): pass

    def population_report(self, Populations, pop_name):
        for org in Populations[pop_name].agents:
            generation = org.status['generation']
            fitness = str(org.status['fitness'])
            blood = ','.join([str(m) for m in org.status['blood']])
            if (generation == 1) or (generation % parameters["print_frequency"]) == 0:
                print(",".join([str(generation), str(fitness), str(blood)]))
        return Populations

    def database_report(self, con, cur, start_time, 
                        Populations, World, generation_count):
        try:
            dose.database_report_populations(con, cur, start_time, 
                                             Populations, generation_count)
        except: pass
        try:
            dose.database_report_world(con, cur, start_time, 
                                       World, generation_count)
        except: pass

    def deployment_scheme(self, Populations, pop_name, World): pass


if __name__ == "__main__":
    if len(sys.argv) == 2: 
        parameters["simulation_name"] = sys.argv[1]
    print('\n[' + parameters["simulation_name"].upper() + ' SIMULATION]')
    print('Adding deployment scheme to simulation parameters...')
    parameters["deployment_scheme"] = simulation_functions.deployment_scheme
    print('Constructing World entity...')
    World = dose.dose_world.World(parameters["world_x"],
                             parameters["world_y"],
                             parameters["world_z"])
    dose.load_all_local_input(World, environmental_data)
    print('Spawning populations...')
    Populations = dose.spawn_populations(parameters)
    print('\nStarting simulation on sequential ecological cell simulator...')
    (simulation_functions, parameters, Populations, World) = \
        dose.sequential_simulator(simulation_functions, parameters, 
                                  Populations, World)
    print('\nSimulation ended...')