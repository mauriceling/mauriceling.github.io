import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Read excel file
df = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\Control_efficiency.xlsx")
df1 = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\MetaboliteSum_efficiency.xlsx")
df2 = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\MetaboliteAverage_efficiency.xlsx")
df3 = pd.read_excel("C:\Users\User\OneDrive\Desktop\Results\4_ProcessedResults\MetaboliteUnique_efficiency.xlsx")

#PLOT
sns.lineplot(data=df, x='Generation', y='DO_Mean', label='Control', errorbar='se', err_style='bars')
sns.lineplot(data=df1, x='Generation', y='DO_Mean', label='Metabolite Sum', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)
sns.lineplot(data=df2, x='Generation', y='DO_Mean', label='Metabolite Average', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)
sns.lineplot(data=df3, x='Generation', y='DO_Mean', label='Metabolite Unique', errorbar='se', err_style='bars', linestyle='--', alpha=0.6)

plt.title("Grand mean of global efficiency across 1000 generations")
plt.xlabel('Generation')
plt.ylabel('Grand mean of global efficiency')
plt.xticks([100,200,300,400,500,600,700,800,900,1000])

plt.show()