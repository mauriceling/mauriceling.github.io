"""
Extension of simplified model of John Boscoh H. Njagarah, Farai Nyabadza. Modelling the role of drug barons on the prevalence of drug epidemics[J]. Mathematical Biosciences and Engineering, 2013, 10(3): 843-860. doi: 10.3934/mbe.2013.10.843
"""
def DP5(funcs, x0, y0, step, xmax, 
        overflow=1e100, zerodivision=1e100):
    yield [x0] + y0
    def solver(funcs, x0, y0, step):
        n = len(funcs)
        f1, f2, f3 = [0]*n, [0]*n, [0]*n
        f4, f5, f6, f7 = [0]*n, [0]*n, [0]*n, [0]*n
        y1 = [0]*n
        for i in range(n):
            try: f1[i] = funcs[i](x0, y0)
            except TypeError: pass
            except ZeroDivisionError: f1[i] = zerodivision
            except OverflowError: f1[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (0.2*step*f1[j])
        for i in range(n):
            try: f2[i] = funcs[i]((x0+(0.2*step)), y1)
            except TypeError: pass
            except ZeroDivisionError: f2[i] = zerodivision
            except OverflowError: f2[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (3*step*f1[j]/40.0) + (9*step*f2[j]/40.0)
        for i in range(n):
            try: f3[i] = funcs[i]((x0+(0.3*step)), y1)
            except TypeError: pass
            except ZeroDivisionError: f3[i] = zerodivision
            except OverflowError: f3[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (44*step*f1[j]/45.0) + (-56*step*f2[j]/15.0) + \
                    (32*step*f3[j]/9.0)
        for i in range(n):
            try: f4[i] = funcs[i]((x0+(0.8*step)), y1)
            except TypeError: pass
            except ZeroDivisionError: f4[i] = zerodivision
            except OverflowError: f4[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (19372*step*f1[j]/6561.0) + \
                    (-25360*step*f2[j]/2187.0) + \
                    (64448*step*f3[j]/6561.0) + \
                    (-212*step*f4[j]/729.0)
        for i in range(n):
            try: f5[i] = funcs[i](x0+(8*step/9.0), y1)
            except TypeError: pass
            except ZeroDivisionError: f5[i] = zerodivision
            except OverflowError: f5[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (9017*step*f1[j]/3168.0) + \
                    (-355*step*f2[j]/33.0) + (46732*step*f3[j]/5247.0) + \
                    (49*step*f4[j]/176.0) + (-5103*step*f5[j]/18656.0)
        for i in range(n):
            try: f6[i] = funcs[i](x0+step, y1)
            except TypeError: pass
            except ZeroDivisionError: f6[i] = zerodivision
            except OverflowError: f6[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (35*step*f1[j]/384.0) + \
                    (500*step*f3[j]/1113.0) + (125*step*f4[j]/192.0) + \
                    (-2187*step*f5[j]/6784.0) + (11*step*f6[j]/84.0)
        for i in range(n):
            try: f7[i] = funcs[i](x0+step, y1)
            except TypeError: pass
            except ZeroDivisionError: f7[i] = zerodivision
            except OverflowError: f7[i] = overflow
        for i in range(n):
            try: y1[i] = y0[i] + (step * \
                    ((35*f1[i]/384.0) + (500*f3[i]/1113.0) + \
                     (125*f4[i]/192.0) + (-2187*f5[i]/6784.0) + \
                     (11*f6[i]/84.0)))
            except TypeError: pass
            except ZeroDivisionError: y1[i] = zerodivision
            except OverflowError: y1[i] = overflow
        return y1
    while x0 < xmax:
        y1 = solver(funcs, x0, y0, step)
        y0 = y1
        x0 = x0 + step
        yield [x0] + y0

p = 0.04
k1 = 0.28
k2 = 0.56
k3 = 0.223
g1 = 0.20
g2 = 0.4
g3 = 0.25 
g4 = 0.325 # average of g2 and g3
g5 = 0.283 # average of g1, g2 and g3
a1 = 0.4
a2 = 0.04
a3 = 0.08
r1 = 0.02
r2 = 0.0014
r3 =  0.003
r4 = 0.2
r5 = 0.028

def S(t, y):
    incoming = p + (g1 * y[1]) + (g5 * y[3])
    outgoing = (k1 * y[0]) + (a1 * y[0] * y[4])
    removed = r1 * y[0]
    return incoming - outgoing - removed
def L(t, y):
    incoming = (k1 * y[0]) + (a1 * y[0] * y[4] ) + (g2 * y[2]) + (g4 * y[3])
    outgoing = (k2 * y[1])+ (a2 * y[1]) + (g1 * y[1])
    removed = r1 * y[1]
    return incoming - outgoing - removed
def H(t, y):
    incoming = (k2 * y[1]) + (g3 * y[3])
    outgoing = (a2 * y[1]) + (k3 * y[2]) + (g2 * y[2])
    removed = (r1 + r2) * y[2]
    return incoming - outgoing - removed
def T(t, y):
    incoming = (k3 * y[2])
    outgoing = (g3 * y[3]) + (g4 * y[3]) + (g5 * y[3])
    removed = (r1 + r3 + r4) * y[3]
    return incoming - outgoing - removed
def D(t, y):
    incoming = (a2 * y[1]) + (a3 * y[2])
    removed = ((r1 + r5) * y[4])
    return incoming - removed
def R(t, y):
    incoming = (r1 * y[0]) + (r1 * y[1]) + ((r1 + r2) * y[2]) + ((r1 + r3 + r4) * y[3]) + ((r1 + r5) * y[4])
    return incoming

f = list(range(6))
f[0] = S
f[1] = L
f[2] = H
f[3] = T
f[4] = D 
f[5] = R

y = list(range(6))
y[0] = 99.9939  # S = Susceptible and at risk
y[1] = 0.005    # L = Light drug users
y[2] = 0.0005   # H = Heavy drug user
y[3] = 0.0005   # T = Rehabilitated drug users
y[4] = 0.0001   # D = Drug lords
y[5] = 0        # R = Removed or dead 

print(','.join(["Time", "S", "L", "H", "T", "D", "R"]))
for i in [x for x in DP5(f, 0.0, y, 0.1, 50.0)]:
    print (','. join ([str(z) for z in i]))