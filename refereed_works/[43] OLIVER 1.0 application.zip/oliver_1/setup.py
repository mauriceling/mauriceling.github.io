from distutils.core import setup
import py2exe

# Make Windows executable:python setup.py py2exe

setup(name='oliver',
      version='1.0',
      description='A set of tools for identifying suitable reference (invariant) genes from large transcriptome datasets',
      long_description='A set of tools for identifying suitable reference (invariant) genes from large transcriptome datasets',
      author='Maurice HT Ling',
      author_email='mauriceling@acm.org',
      license = 'General Public License version 3',
      console=['oliver.py'])
