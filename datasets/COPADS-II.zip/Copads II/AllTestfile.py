import unittest
import AllTests as N

class testChiSquareDistribution(unittest.TestCase):

    def testChiSquarePopVar(self):
        """Test 15: Chi-square test for a population variance"""
        self.assertAlmostEqual(N.ChiSquarePopVar(values = (70, 71, 71, 69, 69, 
            72, 72, 68, 68, 67, 67, 73, 73, 74, 74, 66, 66, 65, 65,
            75, 75, 76, 76, 64, 64), ssize = 25, pv = 9, 
            confidence = 0.95)[2], 40.4, places = 1)
        self.assertTrue(N.ChiSquarePopVar(values = (70, 71, 71, 69, 69, 
            72, 72, 68, 68, 67, 67, 73, 73, 74, 74, 66, 66, 65, 65, 75, 75, 76,
            76, 64, 64), ssize = 25, pv = 9, confidence = 0.95)[4])

    def testChisq2Variance(self):
        """Test 24: Chi-square test for an assumed population variance"""
        self.assertAlmostEqual(N.Chisq2Variance(ssize = 25, svar = 12, 
        pvar = 9, confidence = 0.95)[2], 32)
        self.assertFalse(N.Chisq2Variance(ssize = 25, svar = 12, 
        pvar = 9, confidence = 0.95)[4])
            
    def testChisqFit(self):
        """Test 37: Chi-square test for goodness of fit"""
        self.assertAlmostEqual(N.ChisqFit(observed = (25, 17, 15, 23, 24, 16), 
        expected = (20, 20, 20, 20, 20, 20), confidence = 0.95)[2], 5.0)
        self.assertFalse(N.ChisqFit(observed = (25, 17, 15, 23, 24, 16), 
        expected = (20, 20, 20, 20, 20, 20), confidence = 0.95)[4])

    def testtx2testofKcounts(self):
        """Test 38: The x2-test for compatibility of K counts"""
        self.assertAlmostEqual(N.tx2testofKcounts(T = (1, 1, 1, 1),
            V = (5, 12, 18, 19), confidence = 0.95)[2], 9.259, places = 2)
        self.assertTrue(N.tx2testofKcounts(T = (1, 1, 1, 1),
            V = (5, 12, 18, 19), confidence = 0.95)[4])
    
    def testChisq2x2(self):
        """Test 40: Chi-square test for consistency in 2x2 table"""
        self.assertAlmostEqual(N.Chisq2x2(s1 = (15, 85), s2 = (4, 77),
            ssize = 180, confidence = 0.95)[2], 4.79, places = 1)
        self.assertTrue(N.Chisq2x2(s1 = (15, 85), s2 = (4, 77), ssize = 180, 
            confidence = 0.95),[4])
            
    def testChisquareKx2table(self):
        """Test 41: The x2-test for consistency in a K x 2 table"""
        self.assertAlmostEqual(N.ChisquareKx2table(c1 = (3, 4, 5),
            c2 = (7, 2, 4), k = 3, confidence = 0.95)[2], 2.344, places = 2)
        self.assertFalse(N.ChisquareKx2table(c1 = (3, 4, 5),
            c2 = (7, 2, 4), k = 3, confidence = 0.95)[4])
            
    def testChisquare2xKtable(self):
        """Test 43: The x2-test for consistency in a 2 x K table"""
        self.assertAlmostEqual(N.Chisquare2xKtable(s1 = (50, 47, 56),
            s2 = (5, 14, 8), k = 3, confidence = 0.95)[2], 4.84, places = 2)
        self.assertFalse(N.Chisquare2xKtable(s1 = (50, 47, 56),
            s2 = (5, 14, 8), k = 3, confidence = 0.95)[4])
    
    def testMedianTestfor2Pop(self):
        """Test 50: The median test of two populations"""
        self.assertAlmostEqual(N.MedianTestfor2Pop(s1 = (9, 6), 
            s2 = (6, 9), confidence = 0.95)[2], 0.53, places = 1)
        self.assertFalse(N.MedianTestfor2Pop(s1 = (9, 6), s2 = (6, 9),
            confidence = 0.95)[4])
    
class testFDistribution(unittest.TestCase):

    def testFVarianceRatio(self):
        """Test 16: F-test for two population variances (variance ratio test)"""
        self.assertAlmostEqual(N.FVarianceRatio(var1 = 0.36, var2 = 0.087, 
            ssize1 = 6, ssize2 = 4, confidence = 0.95)[2], 4.14, places=2)
        self.assertFalse(N.FVarianceRatio(var1 = 0.36, var2 = 0.087,
            ssize1 = 6, ssize2 = 4, confidence = 0.95)[4])

    def testF2CorrelatedObs(self):
        """Test 17: F-test for two population variances 
        with correlated observations)"""
        self.assertAlmostEqual(N.F2CorrelatedObs(var1 = 0.36,
            var2 = 0.087, ssize1 = 6, ssize2 = 6, r = 0.811, 
            confidence = 0.95)[2], 0.796, places = 2)
        self.assertFalse(N.F2CorrelatedObs(var1 = 0.36, var2 = 0.087,
            ssize1 = 6, ssize2 = 6, r = 0.811, confidence = 0.95)[4])
        
    def testF2Count(self):
        """Test 25: F-test for two counts (Poisson distribution)"""
        self.assertAlmostEqual(N.F2Count(count1 = 13, count2 = 3,
            confidence = 0.95)[2], 3.25)
        self.assertTrue(N.F2Count(count1= 13, count2 = 3, 
            confidence = 0.95)[4])

class testTDistribution(unittest.TestCase):
    
    def testt1Mean(self): 
        """Test 7: t-test for a population mean (population variance unknown)"""
        self.assertAlmostEqual(N.t1Mean(smean = 3.1, pmean = 4.0, svar = 1.0,
            ssize = 9, confidence = 0.975)[2], -2.69999999)
        self.assertFalse(N.t1Mean(smean = 3.1, pmean = 4.0, svar = 1.0,
            ssize = 9, confidence = 0.975)[4])
            
    def testt2Mean2EqualVariance(self):
        """Test 8: t-test for two population means (population variance unknown 
        but equal)"""
        self.assertAlmostEqual(N.t2Mean2EqualVariance(smean1 = 31.75, 
            smean2 = 28.67, svar1 = 112.25, svar2 = 66.64, ssize1 = 12, 
            ssize2 = 12, confidence = 0.975)[2], 0.798, places=3)
        self.assertFalse(N.t2Mean2EqualVariance(smean1 = 31.75, 
            smean2 = 28.67, svar1 = 112.25, svar2 = 66.64, ssize1 = 12,
            ssize2 = 12, confidence = 0.975)[4])
    
    def testt2Mean2UnequalVariance(self):
        """Test 9: t-test for two population means (population variance unknown 
        and unequal)"""
        self.assertAlmostEqual(N.t2Mean2UnequalVariance(smean1 = 3166.0, 
            smean2 = 2240.4, svar1 = 6328.67, svar2 = 221661.3, ssize1 = 4, 
            ssize2 = 9, confidence = 0.975)[2], 5.717, places=2)
        self.assertTrue(N.t2Mean2UnequalVariance(smean1 = 3166.0, 
            smean2 = 2240.4, svar1 = 6328.67, svar2 = 221661.3, ssize1 = 4,
            ssize2 = 9, confidence = 0.975)[4])
            
    def testtPaired(self):
        """Test 10: t-test for two population means (method of paired 
        comparisons)"""
        self.assertAlmostEqual(N.tPaired(smean1 = 0.9, smean2 = 1.0, svar = 2.9,
            ssize = 10, confidence=0.975)[2], -0.11, places=2)
        self.assertFalse(N.tPaired(smean1 = 0.9, smean2 = 1.0, svar = 2.9,
            ssize = 10, confidence = 0.975)[4])
            
    def testtRegressionCoefficient(self):
        """Test 11: t-test of a regression coefficient"""
        self.assertAlmostEqual(N.tRegressionCoefficient(variancex = 15.61,
            varianceyx = 92.4, b = 5.029, ssize = 12, confidence = 0.975)[2], 
            0.6232, places=3)
        self.assertFalse(N.tRegressionCoefficient(variancex = 15.61,
            varianceyx = 92.4, b = 5.029, ssize = 12, confidence = 0.975)[4])
    
    def testtPearsonCorrelation(self):
        """Test 12: t-test of a correlation coefficient"""
        self.assertAlmostEqual(N.tPearsonCorrelation(r = 0.32, ssize = 18,
            confidence = 0.95)[2], 1.35, places=2)
        self.assertFalse(N.tPearsonCorrelation(r = 0.32, ssize = 18,
            confidence = 0.95)[4])
                   
            
if __name__ == '__main__':
    unittest.main()
