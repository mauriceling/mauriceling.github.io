# -*- coding: utf-8 -*-
"""
ChemBot - A chemistry-based chatbot trained using 1000 messages.
"""
import os 
import shutil

from chatterbot import ChatBot

try: os.remove("./chemBot_chat.db")
except: pass

shutil.copyfile("./chemBot_220712.db", "./chemBot_chat.db")

# Uncomment the following lines to enable verbose logging
#import logging
#logging.basicConfig(level=logging.INFO)

# Create a new instance of a ChatBot
bot = ChatBot(
    'ChemBot',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    logic_adapters=['chatterbot.logic.BestMatch'],
    database_uri='sqlite:///chemBot_chat.db'
)

print('Type something to begin...')

# The following loop will execute each time the user enters input
while True:
    try:
        user_input = input("Talk to ChemBot > ")
        bot_response = bot.get_response(user_input)
        print("ChemBot: " + str(bot_response))

    # Press ctrl-c or ctrl-d on the keyboard to exit
    except (KeyboardInterrupt, EOFError, SystemExit):
        break