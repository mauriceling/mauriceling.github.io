"""
Substance use epidemiological model written in Python
by 
Yap et al. (2024) Assembly of Substance Use or Abuse Epidemiological Models.
"""
import argparse

# Step 1: Setup command-line parser
parser = argparse.ArgumentParser(prog="python SubstanceUseModel.py", description="Substance use epidemiological model (written in Python) by Yap et al. (2024) Assembly of Substance Use Epidemiological Models.")
# Step 1.1: Compartment initial conditions (in percentage)
parser.add_argument("-S", type=float, default=99.9957, help="Percentage of population that is susceptible without health education (S). Default=49.9939")
parser.add_argument("-C", type=float, default=99.9957, help="Percentage of population that is susceptible with health education (S). Default=50.000")
parser.add_argument("-L", type=float, default=0.005, help="Percentage of population that is light drug user (L). Default=0.005")
parser.add_argument("-H", type=float, default=0.0005, help="Percentage of population that is heavy drug user (H). Default=0.0005")
parser.add_argument("-Ti", type=float, default=0.0002, help="Percentage of population that is under in-patient treatment (Ti). Default=0.0002")
parser.add_argument("-To", type=float, default=0.0003, help="Percentage of population that is under out-patient treatment (To). Default=0.0003")
parser.add_argument("-D", type=float, default=0.0001, help="Percentage of population that is drug sellers (D). Default=0.0001")
parser.add_argument("-Re", type=float, default=0.0005, help="Percentage of population that is in remission (Re). Default=0.0005")
parser.add_argument("-R", type=float, default=0.0, help="Percentage of population that is dead or removed (R). Default=0.0")
parser.add_argument("-Q", type=float, default=0.0, help="Percentage of population that permanently quitted drug use (Q). Default=0.0")
parser.add_argument("-M", type=float, default=0.0, help="Percentage of population that matured from susceptible (M). Default=0.0")
# Step 1.2: Model parameters
parser.add_argument("-p", type=float, default=0.05, help="Recruitment rate from general population into susceptible population without health education (S). Default=0.05")
parser.add_argument("-q", type=float, default=0.15, help="Recruitment rate from general population into susceptible population with health education (C). Default=0.15")
parser.add_argument("-k1", type=float, default=0.2, help="Rate at which susceptible population without health education (S) become light drug users (L) without the effects of drug barons (D). Default=0.2")
parser.add_argument("-k2", type=float, default=0.5, help="Rate at which light users (L) escalates to heavy drug use (H). Default=0.5")
parser.add_argument("-k3", type=float, default=0.4, help="Proportion of heavy drug users (H) exposed to police search. Default=0.4")
parser.add_argument("-k4", type=float, default=0.2, help="Proportion of light drug users (L) exposed to police search. Default=0.2")
parser.add_argument("-k5", type=float, default=1.00, help="Intensity of policing / police search. Default=1.00")
parser.add_argument("-k6", type=float, default=0.05, help="Rate of relapse from remission (Re) to light drug use (L). Default=0.05")
parser.add_argument("-k7", type=float, default=0.01, help="Rate of relapse from remission (Re) to heavy drug use (H). Default=0.01")
parser.add_argument("-k8", type=float, default=0.01, help="Rate of susceptible population without health education (S) become heavy drug users (H) without the effects of drug barons (D). Default=0.01")
parser.add_argument("-k9", type=float, default=1.00, help="Availability of drugs in the system. Default=1.00")
parser.add_argument("-k10", type=float, default=0.3, help="Rate at which susceptible population without health education (S) accepts health education (C). Default=0.3")
parser.add_argument("-k11", type=float, default=0.1, help="Rate at which susceptible population with health education (C) become light drug users (L) without the effects of drug barons (D). Default=0.1")
parser.add_argument("-k12", type=float, default=0.001, help="Rate of susceptible population with health education (C) become heavy drug users (H) without the effects of drug barons (D). Default=0.001")
parser.add_argument("-b1", type=float, default=0.2, help="Proportion of light drug users (L) caught for in-patient treatment (Ti). Therefore, the proportion of light drug users caught for out-patient treatment (To) is (1-b1). Default=0.2")
parser.add_argument("-b2", type=float, default=0.8, help="Proportion of heavy drug users (H) caught for in-patient treatment (Ti). Therefore, the proportion of heavy drug users caught for out-patient treatment (To) is (1-b2). Default=0.8")
parser.add_argument("-g1", type=float, default=0.2, help="Rate at which light users (L) quit and become susceptible without health education (S) again. Default=0.2")
parser.add_argument("-g2", type=float, default=0.4, help="Rate at which heavy users (H) become light users (L), which includes amelioration. Default=0.4")
parser.add_argument("-g3", type=float, default=0.01, help="Rate at which in-patient treatment (Ti) reverted to heavy drug use (H). Default=0.01")
parser.add_argument("-g4", type=float, default=0.02, help="Rate at which in-patient treatment (Ti) reverted to light drug use (L). Default=0.02")
parser.add_argument("-g5", type=float, default=0.2, help="Rate at which in-patient treatment (Ti) enter remission (Re). Default=0.2")
parser.add_argument("-g6", type=float, default=0.015, help="Proportion of light drug users (L) entering remission (Re) on their own accord. Default=0.015")
parser.add_argument("-g7", type=float, default=0.015, help="Rate at which out-patient treatment (To) reverted to heavy drug use (H). Default=0.015")
parser.add_argument("-g8", type=float, default=0.025, help="Rate at which out-patient treatment (To) reverted to light drug use (L). Default=0.025")
parser.add_argument("-g9", type=float, default=0.2, help="Rate at which out-patient treatment (To) enter remission (Re). Default=0.2")
parser.add_argument("-a1", type=float, default=0.4, help="Effective contact rate between drug barons (D) and susceptible population without health education (S). Default=0.4")
parser.add_argument("-a2", type=float, default=0.04, help="Rate at which light users (L) convert from consumer to seller / promoter (D). Default=0.04")
parser.add_argument("-a3", type=float, default=0.08, help="Rate at which heavy users (H) convert from consumer to seller / promoter (D). Default=0.08")
parser.add_argument("-a4", type=float, default=0.2, help="Effective contact rate between drug barons (D) and susceptible population with health education (S). Default=0.2")
parser.add_argument("-r1", type=float, default=0.2, help="Per capita mortality rate of population. Default=0.2")
parser.add_argument("-r2", type=float, default=0.001, help="Removal rate of heavy users (H) due to events related to drug usage. Default=0.001")
parser.add_argument("-r3", type=float, default=0.003, help="Removal rate of rehabilitated users (T) due to events related to drug usage. Default=0.003")
parser.add_argument("-r4", type=float, default=0.1, help="Rate at which in-patient treatment (Ti) permanently quit (Q). Default=0.1")
parser.add_argument("-r5", type=float, default=0.02, help="Removal rate of drug barons (D), which constitutes mainly to law enforcement. Default=0.02")
parser.add_argument("-r6", type=float, default=0.005, help="Rate of susceptible without health education (S) maturing into non-susceptible (M). Default=0.005")
parser.add_argument("-r7", type=float, default=0.01, help="Rate of light users (L) quitting drug use permanently (Q). Default=0.01")
parser.add_argument("-r8", type=float, default=0.1, help="Rate at which out-patient treatment (To) permanently quit (Q). Default=0.1")
parser.add_argument("-r9", type=float, default=0.01, help="Rate of susceptible with health education (C) maturing into non-susceptible (M). Default=0.01")
parser.add_argument("-c1", type=float, default=0.001, help="Rate of out-patient treatment (To) entering in-patient treatment (Ti). Default=0.001")
parser.add_argument("-c2", type=float, default=0.01, help="Rate of in-patient treatment (Ti) entering out-patient treatment (To). Default=0.01")
# Step 1.3: Simulation parameters
parser.add_argument("-step", type=float, default=0.00274, help="Simulation time step. Default=0.00274")
parser.add_argument("-end", type=float, default=10.0, help="Simulation end time. Default=10.0")
# Step 1.4: Get command-line options 
args = parser.parse_args()

# Step 2: Initial conditions in percentage
y = list(range(11))
y[0] = args.S
y[1] = args.C
y[2] = args.L
y[3] = args.H
y[4] = args.Ti
y[5] = args.To
y[6] = args.D
y[7] = args.Re
y[8] = args.R
y[9] = args.Q
y[10] = args.M
print("--- Compartment Initial Conditions ---")
compartment_names = ["S", "C", "L", "H", "Ti", "To", "D", "Re", "R", "Q", "M"]
for i in range(len(compartment_names)):
    print("%s = %f" % (compartment_names[i], y[i]))

# Step 3: Model parameters
print("--- Model Parameters ---")
p = args.p
print("p = %f" % p)
q = args.q 
print("q = %f" % q)
k1 = args.k1 
print("k1 = %f" % k1)
k2 = args.k2 
print("k2 = %f" % k2)
k3 = args.k3 
print("k3 = %f" % k3)
k4 = args.k4 
print("k4 = %f" % k4)
k5 = args.k5 
print("k5 = %f" % k5)
k6 = args.k6 
print("k6 = %f" % k6)
k7 = args.k7 
print("k7 = %f" % k7)
k8 = args.k8 
print("k8 = %f" % k8)
k9 = args.k9 
print("k9 = %f" % k9)
k10 = args.k10 
print("k10 = %f" % k10)
k11 = args.k11 
print("k11 = %f" % k11)
k12 = args.k12 
print("k12 = %f" % k12)
b1 = args.b1 
print("b1 = %f" % b1)
b2 = args.b2 
print("b2 = %f" % b2)
g1 = args.g1 
print("g1 = %f" % g1)
g2 = args.g2 
print("g2 = %f" % g2)
g3 = args.g3 
print("g3 = %f" % g3)
g4 = args.g4 
print("g4 = %f" % g4)
g5 = args.g5 
print("g5 = %f" % g5)
g6 = args.g6 
print("g6 = %f" % g6)
g7 = args.g7 
print("g7 = %f" % g7)
g8 = args.g8 
print("g8 = %f" % g8)
g9 = args.g9 
print("g9 = %f" % g9)
a1 = args.a1 
print("a1 = %f" % a1)
a2 = args.a2 
print("a2 = %f" % a2)
a3 = args.a3 
print("a3 = %f" % a3)
a4 = args.a4 
print("a4 = %f" % a4)
r1 = args.r1 
print("r1 = %f" % r1)
r2 = args.r2 
print("r2 = %f" % r2)
r3 = args.r3 
print("r3 = %f" % r3)
r4 = args.r4 
print("r4 = %f" % r4)
r5 = args.r5 
print("r5 = %f" % r5)
r6 = args.r6 
print("r6 = %f" % r6)
r7 = args.r7 
print("r7 = %f" % r7)
r8 = args.r8 
print("r8 = %f" % r8)
r9 = args.r9 
print("r9 = %f" % r9)
c1 = args.c1 
print("c1 = %f" % c1)
c2 = args.c2 
print("c2 = %f" % c2)

# Step 4: Set up ODEs
def S(t, y): 
    # Susceptible without health education (S), y[0] = args.S
    # S = [p + g1L] - [r1S + r6S + k1k9S + k8k9S + a1SD + k10S]
    incoming = p + g1*y[2]
    outgoing = r1*y[0] + r6*y[0] + k1*k9*y[0] + k8*k9*y[0] + a1*y[0]*y[6] + k10*y[0]
    return incoming - outgoing
def C(t, y): 
    # Susceptible with health education (C), y[1] = args.C
    # C = [q + k10S] - [r9C + r1C + k9k11C + k9k12C + a4CD]
    incoming = q + k10*y[0]
    outgoing = r9*y[1] + r1*y[1] + k9*k11*y[1] + k9*k12*y[1] + a4*y[1]*y[6]
    return incoming - outgoing
def L(t, y): 
    # Light drug users (L), y[2] = args.L
    # L = [k1k9S + a1SD + k9k11C + a4CD + g2H + g4Ti + g8To + k6Re] - [g1L + k2L + k4k5(b1)L + k4k5(1-b1)L + r1L + a2L + g6L + r7L]
    incoming = k1*k9*y[0] + a1*y[0]*y[6] + k9*k11*y[1] + a4*y[1]*y[6] + g2*y[3] + g4*y[4] + g8*y[4] + k6*y[7]
    outgoing = g1*y[2] + k2*y[2] + k4*k5*(b1)*y[2] + k4*k5*(1-b1)*y[2] + r1*y[2] + a2*y[2] + g6*y[2] + r7*y[2]
    return incoming - outgoing
def H(t, y):
    # Heavy drug users (H), y[3] = args.H
    # H = [k8k9S + k9k12C + k2L + g3Ti + g7To + k7Re] - [a3H + g2H + (r1+r2)H + k3k5(b2)H + k3k5(1-b2)H]
    incoming = k8*k9*y[0] + k9*k12*y[1] + k2*y[2] + g3*y[4] + g7*y[4] + k7*y[7]
    outgoing = a3*y[3] + g2*y[3] + (r1+r2)*y[3] + k3*k5*(b2)*y[3] + k3*k5*(1-b2)*y[3]
    return incoming - outgoing
def Ti(t, y):
    # In-patient treatment (Ti), y[4] = args.Ti
    # Ti = [k4k5(b1)L + k3k5(b2)H + c1To] - [g4Ti + g3Ti + c2Ti + g5Ti + r4Ti + (r1+r2+r3)Ti]
    incoming = k4*k5*(b1)*y[2] + k3*k5*(b2)*y[3] + c1*y[5]
    outgoing = g4*y[4] + g3*y[4] + c2*y[4] + g5*y[4] + r4*y[4] + (r1+r2+r3)*y[4]
    return incoming - outgoing
def To(t, y):
    # Out-patient treatment (To), y[5] = args.To
    # To = [k4k5(1-b1)L + k3k5(1-b2)H + c2Ti] - [g8To + g7To + c1To + g9To + r8To + (r1+r3+r4)To]
    incoming = k4*k5*(1-b1)*y[2] + k3*k5*(1-b2)*y[3] + c2*y[4]
    outgoing = g8*y[5] + g7*y[5] + c1*y[5] + g9*y[5] + r8*y[5] + (r1+r3+r4)*y[5]
    return incoming - outgoing
def D(t, y):
    # Drug sellers (D), y[6] = args.D
    # D = [a2L + a3H] - [(r1+r5)D]
    incoming = a2*y[2] + a3*y[3]
    outgoing = (r1+r5)*y[6]
    return incoming - outgoing
def Re(t, y):
    # Remission (Re), y[7] = args.Re
    # Re = [g6L + g5Ti + g9To] - [k6Re + k7Re + r1Re]
    incoming = g6*y[2] + g5*y[5] + g9*y[5]
    outgoing = k6*y[7] + k7*y[7] + r1*y[7]
    return incoming - outgoing
def R(t, y):
    # Removed (R), y[8] = args.R
    # R = r1S + r1C + (r1+r5)D + r1L + (r1+r2)H + (r1+r2+r3)Ti + (r1+r3+r4)To + r1Re
    incoming = r1*y[0] + r1*y[1] + (r1+r5)*y[6] + r1*y[2] + (r1+r2)*y[3] + (r1+r2+r3)*y[4] + (r1+r3+r4)*y[5] + r1*y[7]
    return incoming
def Q(t, y):
    # Quitted (Q), y[9] = args.Q
    # Q = r7L + r4Ti + r8To
    incoming = r7*y[2] + r4*y[4] + r8*y[5]
    return incoming
def M(t, y):
    # Matured (M), y[10] = args.M
    # M = [r6S + r9C]
    incoming = r6*y[0] + r9*y[2]
    return incoming

# Step 5: Model setup
f = list(range(11))
f[0] = S
f[1] = C
f[2] = L
f[3] = H
f[4] = Ti
f[5] = To
f[6] = D
f[7] = Re
f[8] = R
f[9] = Q
f[10] = M

# Step 6: ODE solver
def DP5(funcs, x0, y0, step, xmax, 
        overflow=1e100, zerodivision=1e100):
    yield [x0] + y0
    def solver(funcs, x0, y0, step):
        n = len(funcs)
        f1, f2, f3 = [0]*n, [0]*n, [0]*n
        f4, f5, f6, f7 = [0]*n, [0]*n, [0]*n, [0]*n
        y1 = [0]*n
        for i in range(n):
            try: f1[i] = funcs[i](x0, y0)
            except TypeError: pass
            except ZeroDivisionError: f1[i] = zerodivision
            except OverflowError: f1[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (0.2*step*f1[j])
        for i in range(n):
            try: f2[i] = funcs[i]((x0+(0.2*step)), y1)
            except TypeError: pass
            except ZeroDivisionError: f2[i] = zerodivision
            except OverflowError: f2[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (3*step*f1[j]/40.0) + (9*step*f2[j]/40.0)
        for i in range(n):
            try: f3[i] = funcs[i]((x0+(0.3*step)), y1)
            except TypeError: pass
            except ZeroDivisionError: f3[i] = zerodivision
            except OverflowError: f3[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (44*step*f1[j]/45.0) + (-56*step*f2[j]/15.0) + \
                    (32*step*f3[j]/9.0)
        for i in range(n):
            try: f4[i] = funcs[i]((x0+(0.8*step)), y1)
            except TypeError: pass
            except ZeroDivisionError: f4[i] = zerodivision
            except OverflowError: f4[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (19372*step*f1[j]/6561.0) + \
                    (-25360*step*f2[j]/2187.0) + \
                    (64448*step*f3[j]/6561.0) + \
                    (-212*step*f4[j]/729.0)
        for i in range(n):
            try: f5[i] = funcs[i](x0+(8*step/9.0), y1)
            except TypeError: pass
            except ZeroDivisionError: f5[i] = zerodivision
            except OverflowError: f5[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (9017*step*f1[j]/3168.0) + \
                    (-355*step*f2[j]/33.0) + (46732*step*f3[j]/5247.0) + \
                    (49*step*f4[j]/176.0) + (-5103*step*f5[j]/18656.0)
        for i in range(n):
            try: f6[i] = funcs[i](x0+step, y1)
            except TypeError: pass
            except ZeroDivisionError: f6[i] = zerodivision
            except OverflowError: f6[i] = overflow
        for j in range(n):
            y1[j] = y0[j] + (35*step*f1[j]/384.0) + \
                    (500*step*f3[j]/1113.0) + (125*step*f4[j]/192.0) + \
                    (-2187*step*f5[j]/6784.0) + (11*step*f6[j]/84.0)
        for i in range(n):
            try: f7[i] = funcs[i](x0+step, y1)
            except TypeError: pass
            except ZeroDivisionError: f7[i] = zerodivision
            except OverflowError: f7[i] = overflow
        for i in range(n):
            try: y1[i] = y0[i] + (step * \
                    ((35*f1[i]/384.0) + (500*f3[i]/1113.0) + \
                     (125*f4[i]/192.0) + (-2187*f5[i]/6784.0) + \
                     (11*f6[i]/84.0)))
            except TypeError: pass
            except ZeroDivisionError: y1[i] = zerodivision
            except OverflowError: y1[i] = overflow
        return y1
    while x0 < xmax:
        y1 = solver(funcs, x0, y0, step)
        y0 = y1
        x0 = x0 + step
        yield [x0] + y0

# Step 7: Simulation parameters
time_step = args.step
end_time = args.end

# Step 9: Simulate model
print("--- Simulation Results ---")
print(",".join(["Time", "S", "C", "L", "H", "Ti", "To", "D", "Re", "R", "Q", "M"]))
for i in [x for x in DP5(f, 0.0, y, time_step, end_time)]:
    print (",". join ([str(z) for z in i]))
