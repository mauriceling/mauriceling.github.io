"""
Bact-ome: A module for analysing bacterial omics

Copyright 2009 Maurice Ling <mauriceling@acm.org> on behalf of
Maurice Ling, Chin-How Lee, Jack Si-Hao Oon, Kun-Cheng Lee.

This program is free software: you can redistribute it and/or modify it under 
the terms of the Lesser GNU General Public License as published by the Free 
Software Foundation, either version 3 of the License, or (at your option) any 
later version.

This program is distributed in the hope that it will be useful, but WITHOUT A
NY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the Lesser GNU General Public License along 
with this program. If not, see <http://www.gnu.org/licenses/>

   
Categorical List of Functions:
    1. Read sequence data files
        - fasta_seq: Opens a fasta format file to read the sequence.
    2. Finding primers for RAPD from genome
        - generate_all_LCS: Generate primer data file from DNA fragment file.
        - generate_fragments: Cuts sequence into sequential fragments of 
            specified length.
        - generate_primers_from_fasta: Generate a file of primers with amplicon
            size and genomic position from the Fasta sequence file.
        - get_LCS_by_amplicon: Extract all the primers and amplicon positions 
            from primer data file.
        - inverse_LCS: Generates the index file of primer data file.
        - LCS: Find longest common substring in 2 given strings.
        - LCS_uniqueness: Analyze primer data file and group primers based on 
            the number of amplicons generated.
        - LCS_tabulate: Tabulate primers data file, grouped by amplicon size.
        - look_for_primers: Identify primers from inverse primer file.
    3. Calculate generation time
        - generation: Calculates generation time from 2 OD readings.
        - totalgen: Calculates the total logarithmic phase generations in a
            series of batch culture.
    4. Perform restriction endonuclease digestion
        - restriction_digest: Performs restriction digest and bin results into 
            3 groups.
        - restriction_supplier: Performs restriction endonuclease analysis by
            batch, based on supplier.
        - Nei_Li: Calculates the dissimilarity between 2 band patterns.
    5. Computationally-intensive statistical methods
        - bootstrap: Calculates bootstrapped means and standard deviation.
        - randomization: Performs randomization test, also known as permutation
            test.
"""
import anydbm
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import generic_dna
import math

from marshaldbm import marshaldbm

def fasta_seq(fasta='ATCC8739.fasta'):
    """
    Open fasta format file and returns the sequence.
    """
    f = SeqIO.parse(open(fasta, 'rU'), 'fasta').next()
    return f.seq

def generate_fragments(seq, tablefile, fragment_size=15):
    """
    Slice an entire sequence into fragments of equal lengths
    
    Parameters:
        seq = sequence to be sliced (output from fasta_seq function)
        tablefile = name of file to store the sliced sequence
        fragment_size = length of each sequence to be sliced into. This will
            be the maximum primer/probe length.
            Default value is 15 bases.
    """
    genome_fragment = anydbm.open(tablefile, 'c')
    last_start= len(seq) - fragment_size
    count = 0
    for start in range(0, last_start, fragment_size):
        genome_fragment[str(count)] = seq[start:15+start].data
        count = count + 1
        if (count % 1000) == 0:
            print str(count) + ' fragments inserted into ' + tablefile
    print str(count) + ' fragments inserted into ' + tablefile
    genome_fragment.close()

def LCS(seq, test):
    """
    Finds the longest common substring between the 2 inputs (seq and test).
    
    Adapted from http://en.wikibooks.org/wiki/Algorithm_Implementation/
    Strings/Longest_common_substring
    """
    m = len(seq)
    n = len(test)
    L = [[0] * (n+1) for i in xrange(m+1)]
    LCS = set()
    longest = 0
    for i in xrange(m):
        for j in xrange(n):
            if seq[i] == test[j]:
                v = L[i][j] + 1
                L[i+1][j+1] = v
                if v > longest:
                    longest = v
                    LCS = set()
                if v == longest:
                    LCS.add(seq[i-v+1:i+1])
    return LCS

def generate_all_LCS(fragfile, LCSfile, 
                     min_primer=7, max_interval=198, min_interval=6):
    """
    Generates primers where forward primer sequence = reverse primer sequence
    given the size of amplicon and minimum length of primers.
    
    Parameters:
        fragfile = file of sliced sequence (tablefile parameter of 
            generate_fragments function)
        LCSfile = name of file to store least common substrings' (primers) data 
        min_primer = smallest acceptable length for primers
        max_interval = number of maximum fragment intervals between 2 primers. 
            This value is determines the maximum length of amplicon generated 
            and is determined by the length of each sliced fragment.
            Default value is 198 as 3000bp amplicon is the maximum normal
            Taq polymerase can amplify. 198 intervals of 15 bases per 
            fragment + 2 flanking fragment of maximum of 15 bases (primer
            length) gives a total of 200 fragments of 15 bases = 3000 bases.
        min_interval = number of minimum fragment intervals between 2 primers. 
            This value is determines the maximum length of amplicon generated 
            and is determined by the length of each sliced fragment.
            Default value is 6 as 120bp amplicon is the minimum length visible
            on 1.5% agarose gel that is also suitable for 3000 bp. 6 intervals 
            of 15 bases per fragment + 2 flanking fragment of maximum of 15 
            bases (primer length) gives a total of 8 fragments of 15 bases = 
            120 bases.
    """
    genome_fragment = anydbm.open(fragfile, 'c')
    num_of_frag = len(genome_fragment)
    num_analyzed = 0
    result = {}
    fragment_size = len(genome_fragment['0'])
    for size in range(max_interval, min_interval, -1):
        com_seq = anydbm.open(LCSfile, 'c')
        print 'Analysing for ' + str(fragment_size * size) + 'bp amplicons'
        num_com = 0
        for frag in range(0, num_of_frag - size):
            p1 = genome_fragment[str(frag)]
            p2 = genome_fragment[str(frag+size)]
            p2 = Seq(p2, generic_dna).reverse_complement().data
            try: common_seq = LCS(p1, p2).pop()
            except : common_seq = ''
            num_analyzed = num_analyzed + 1
            if len(common_seq) > min_primer:
                com_seq['|'.join([str(frag), str(frag+size),
                                  str(size)])] = common_seq
                num_com = num_com + 1
            if (num_analyzed % 10000) == 0:
                print str(num_analyzed) + ' pairs analyzed'
                print '        ' + str(num_com) + ' LCS more than ' + \
                      str(min_primer) + 'bp for ' + \
                      str(15 * size) + 'bp amplicons'
        com_seq.close()
        result[size] = str(num_com)
    print str(num_analyzed) + ' pairs analyzed'
    print '        ' + str(num_com) + ' LCS more than ' + str(min_primer) + \
        'bp for ' + str(15 * size) + 'bp amplicons'
    genome_fragment.close()
    return result

def get_LCS_by_amplicon(LCSfile, amplicon_size):
    """
    Extract all the primers and amplicon positions from the LCSfile given the
    amplicon length.
    
    Parameters:
        LCSfile = file of least common substrings' (primers) data
        amplicon_size = size of amplified product in terms of number of
            fragments intervening 2 primers. For example, if the fragment 
            size is 15 and the amplicon size is 60, we are then looking
            for primers (forward primer sequence = reverse primer
            sequence) that gives amplicons of 900 bp (60*15) excluding
            the flanking primers.
    
    Returns:
        (List of primers,
        List of amplicons' data)
        where
        1. each data element in "List of amplicons' data" is in the format of
           '<start fragment position>|<end fragment position>|<amplicon size>'
            <start fragment position> and <end fragment position> multiplied 
            by the fragment size will give the corresponding position on the 
            fasta sequence. For example, '89572|89632|60' represents the 
            amplicon from 1343580 bp (889572*15) to 1344480 bp (89632*15) of 
            the fasta sequence, corresponding to an amplicon size of 900bp 
            (60*15).
        2. the number of primers = number of primers's data. This means that in
            primers = get_LCS_by_amplicon('primer.table', 60)
            primers[0][10] sequence will amplify primers[1][10]
    """
    com_seq = anydbm.open(LCSfile, 'c')
    keys = com_seq.keys()
    return ([com_seq[x]
             for x in keys
                 if x.split('|')[2] == str(amplicon_size)],
            [x
             for x in keys
                 if x.split('|')[2] == str(amplicon_size)])
    
def LCS_uniqueness(LCSfile, amplicon_size):
    """
    Extract all the primers and amplicon positions from the LCSfile given the
    amplicon length and groups the primers into 2 groups: those that only 
    yield one amplicon and those that yield more than one amplicons.
    
    Parameters:
        LCSfile = file of least common substrings' (primers) data
        amplicon_size = size of amplified product in terms of number of
            fragments intervening 2 primers. For example, if the fragment 
            size is 15 and the amplicon size is 60, we are then looking
            for primers (forward primer sequence = reverse primer
            sequence) that gives amplicons of 900 bp (60*15) excluding
            the flanking primers.
    
    Returns:
        (List of unique primers,
        List of non-unique primers)
        where 'List of unique primers' are primers amplifying only one 
        amplicon, and 'List of non-unique primers' is a tuple of 'number
        of amplicons' and primer sequence.
    """
    LCS = get_LCS_by_amplicon(LCSfile, amplicon_size)[0]
    unique_LCS = [x
                  for x in LCS
                      if LCS.count(x) == 1]
    non_unique_LCS = list(set([(LCS.count(x), x)
                               for x in LCS
                                   if LCS.count(x) > 1]))
    return (unique_LCS, non_unique_LCS)
    
def LCS_tabulate(LCSfile, max_interval=198, min_interval=6, 
                 fragment_size=15, p='yes'):
    """
    Provides a tabulation of the given LCSfile, grouped by amplicon size.
    
    Parameters:
        LCSfile = file of least common substrings' (primers) data
        max_interval = number of maximum fragment intervals between 2 primers. 
            This value is determines the maximum length of amplicon generated 
            and is determined by the length of each sliced fragment.
            Default value is 198 as 3000bp amplicon is the maximum normal
            Taq polymerase can amplify. 198 intervals of 15 bases per 
            fragment + 2 flanking fragment of maximum of 15 bases (primer
            length) gives a total of 200 fragments of 15 bases = 3000 bases.
        min_interval = number of minimum fragment intervals between 2 primers. 
            This value is determines the maximum length of amplicon generated 
            and is determined by the length of each sliced fragment.
            Default value is 6 as 120bp amplicon is the minimum length visible
            on 1.5% agarose gel that is also suitable for 3000 bp. 6 intervals 
            of 15 bases per fragment + 2 flanking fragment of maximum of 15 
            bases (primer length) gives a total of 8 fragments of 15 bases = 
            120 bases.
        fragment_size = length of each sequence to be sliced into. This will
            be the maximum primer/probe length.
            Default value is 15 bases.
        p = flag to determine if the tabulation data is to be printed. 
            Default = yes
    """
    result = {}
    for amplicon_size in range(max_interval, min_interval, -1):
        (unique_LCS, non_unique_LCS) = LCS_uniqueness(LCSfile, amplicon_size)
        if p == 'yes':
            print 'Longest Common Substring (primer) for amplicon size of ' + \
                str(amplicon_size*fragment_size)
            print 'Unique Primers (only one amplicon). N = ' + \
                str(len(unique_LCS))
            print '  '.join(unique_LCS)
            print
            print 'Non-Unique Primers (more than one amplicon)'
            print '\t'.join(['# amplicons', 'Primer sequence'])
            for lcs in non_unique_LCS:
                print '\t\t'.join([str(lcs[0]), lcs[1]])
            print
            print
        result[str(amplicon_size)] = (unique_LCS, non_unique_LCS)
    return result

def inverse_LCS(LCSfile, inverseLCSfile, max_interval=198, min_interval=6, 
                fragment_size=15):
    """
    Generates the index file of LCSfile. 
    
    Format of LCSfile: <start fragment position>|
                       <end fragment position>|
                       <amplicon size> = <primer sequence>
    Format of inverseLCSfile: <primer sequence> =
                              [<start fragment position>|
                               <end fragment position>|
                               <amplicon size>, ...]
    
    Parameters:
        LCSfile = file of least common substrings' (primers) data
        inverseLCSfile = name of file to store the index of LCSfile
        max_interval = number of maximum fragment intervals between 2 primers. 
            This value is determines the maximum length of amplicon generated 
            and is determined by the length of each sliced fragment.
            Default value is 198 as 3000bp amplicon is the maximum normal
            Taq polymerase can amplify. 198 intervals of 15 bases per 
            fragment + 2 flanking fragment of maximum of 15 bases (primer
            length) gives a total of 200 fragments of 15 bases = 3000 bases.
        min_interval = number of minimum fragment intervals between 2 primers. 
            This value is determines the maximum length of amplicon generated 
            and is determined by the length of each sliced fragment.
            Default value is 6 as 120bp amplicon is the minimum length visible
            on 1.5% agarose gel that is also suitable for 3000 bp. 6 intervals 
            of 15 bases per fragment + 2 flanking fragment of maximum of 15 
            bases (primer length) gives a total of 8 fragments of 15 bases = 
            120 bases.
        fragment_size = length of each sequence to be sliced into. This will
            be the maximum primer/probe length.
            Default value is 15 bases.
    """
    inverseLCSfile = marshaldbm(inverseLCSfile, 'c')
    count = 0
    for amplicon_size in range(max_interval, min_interval, -1):
        seq, pos = get_LCS_by_amplicon(LCSfile, amplicon_size)
        print 'Processing for amplicon size of ' + \
            str(amplicon_size*fragment_size)
        for index in range(len(seq)):
            count = count + 1
            try:
                temp = inverseLCSfile[seq[index]]
                inverseLCSfile[seq[index]] = temp + [pos[index]]
            except KeyError:
                inverseLCSfile[seq[index]] = [pos[index]]
            if (count % 1000) == 0:
                print str(count) + ' LCS processed'
    print str(count) + ' LCS processed'
    inverseLCSfile.close()

def look_for_primers(inverseLCSfile, num_of_amplicons, min_tm, p='yes'):
    """
    Scans the LCSfile index for primer(s) that amplifies a given number of
    amplicons. The primer must not end with adenosine and thymidine, and
    must meet minimum annealing temperature.
    
    Parameters:
        inverseLCSfile = name of LCSfile index file
        num_of_amplicons = number of amplicons generated by required primer(s)
        min_tm = minimum annealing temperature (in degrees centigrade) of 
            primers. Calculated as 2AT + 4GC.
        p = flag to determine if data is to be printed. Default = yes
    
    Returns:
        List of primers meeting the criteria
    """
    f = marshaldbm(inverseLCSfile, 'c')
    keys = f.keys()
    primers = []
    for k in keys:
        temperature = 4*(k.count('G')+k.count('C')) + \
                      2*(k.count('A')+k.count('T'))
        if (len(f[k])) == num_of_amplicons and \
           temperature > min_tm-1 and \
           not k.endswith('A') and not k.endswith('T'):
            primers.append(k)
            if p == 'yes':
                print k
                print f[k]
                print
    return primers
            
def generate_primers_from_fasta(fasta='ATCC8739.fasta',
                                genome_fragment='genome_fragment.table',
                                max_primer_length=15,
                                min_primer_length=7,
                                max_amplicon_length=3100,
                                min_amplicon_length=300,
                                primer_file='primer.table',
                                inverse_primer_file='invprimer.table'):
    """
    Generate a file of primers with amplicon size and genomic position from
    the Fasta sequence file.
    
    Parameters:
        fasta = name of fasta file to process
        genome_fragment = name of file to store the sliced sequence.
            Default = 'genome_fragment.table'
        max_primer_length = maximum length of primer (fragment size of genome
            slices). Default = 15 bp
        min_primer_length = minimum length of primer. Default = 7 bp
        max_amplicon_length = maximum size of amplicon. Default = 3100 bp
        min_amplicon_length = minimum size of amplicon. Default = 300 bp
        primer_file = file of least common substrings' (primers) data.
            Default = 'primer.table'
        inverse_primer_file = name of primers index file. 
            Default = 'invprimer.table'
    
    Output files:
        1. genome fragment file from 'generate_fragments' function
        2. primer file from 'generate_all_LCS' function
        3. inverse primer file from 'inverse_LCS' function
    """
    seq = fasta_seq(fasta)
    generate_fragments(seq, genome_fragment, fragment_size=max_primer_length)
    generate_all_LCS(genome_fragment, primer_file, 
                     min_primer_length, 
                     int(max_amplicon_length/max_primer_length), 
                     int(min_amplicon_length/max_primer_length))
    inverse_LCS(primer_file, inverse_primer_file, 
                int(max_amplicon_length/max_primer_length), 
                int(min_amplicon_length/max_primer_length), 
                max_primer_length)

def restriction_digest(seq, enzyme, max_band=23130, min_band=2000, 
                       linear=False, p='yes'):
    """
    Performs restriction endonuclease digestion on a sequence and group the
    resulting fragments into 3 groups so simulate different agarose gel
    electrophoresis:
    1. fragment length more than the maximum size
    2. fragment length between the maximum and minimum size
    3. fragment length less than the minimum size
    
    Parameters:
        seq = DNA sequence for restriction endonuclease digestion
        enzyme = Restriction endonuclease object from Bio.Restriction
            package
        max_band = size of maximum band in basepairs. Default = 23130
        min_band = size of minimum band in basepairs. Default = 2000
        linear = flag to define if DNA sequence is linear.
            Default = False (DNA is circular)
        p = flag to determine if the data is to be printed. Default = yes
        
    Result:
        (Number of fragments after digestion, 
        List of fragments with molecular size above max_band, 
        List of fragments with molecular size between max_band and min_band, 
        List of fragments with molecular size below min_band)
    """
    digest = enzyme.search(seq, linear=linear)
    digest.sort()
    fragment = [digest[x+1] - digest[x]
                for x in range(len(digest) - 1)]
    fragment.sort()
    ogel = [x for x in fragment if x > max_band]
    gel = [x for x in fragment if x <= max_band and x >= min_band]
    ugel = [x for x in fragment if x < min_band]
    ogel.sort()
    gel.sort()
    ugel.sort()
    if p == 'yes':
        print 'Enzyme: ' + str(enzyme)
        print 'Restriction site: ' + enzyme.site
        print 'Number of fragments: ' + str(len(fragment))
        print 'Number of fragments (x > ' + str(max_band) + '): ' + \
            str(len(ogel))
        print 'Number of fragments (' + str(max_band) + ' < x < ' + \
            str(min_band) + '): ' + str(len(gel))
        print 'Number of fragments (x < ' + str(min_band) + '): ' + \
            str(len(ugel))
        print
    return (len(fragment), ogel, gel, ugel)

def restriction_supplier(seq, max_band=23130, min_band=2000,
                         suppliers='ACEGFIHKJMONQPSRUVX',
                         linear=False, p='yes'):
    """
    Performs restriction endonuclease analysis by batch, based on supplier.
    
    Parameters:
        seq = DNA sequence for restriction endonuclease digestion
        max_band = size of maximum band in basepairs. Default = 23130
        mmin_band = size of minimum band in basepairs. Default = 2000
        suppliers = restriction enzyme supplier. Default = ACEGFIHKJMONQPSRUVX
            where
                A = Amersham Pharmacia Biotech
                C = Minotech Biotechnology
                E = Stratagene
                G = Qbiogene
                F = Fermentas AB
                I = SibEnzyme Ltd.
                H = American Allied Biochemical, Inc.
                K = Takara Shuzo Co. Ltd.
                J = Nippon Gene Co., Ltd.
                M = Roche Applied Science
                O = Toyobo Biochemicals
                N = New England Biolabs
                Q = CHIMERx
                P = Megabase Research Products
                S = Sigma Chemical Corporation
                R = Promega Corporation
                U = Bangalore Genei
                V = MRC-Holland
                X = EURx Ltd.
        linear = flag to define if DNA sequence is linear.
            Default = False (DNA is circular)
        p = flag to determine if the data is to be printed. Default = yes

    Returns:
    {Restriction endonuclease :
        (Total number of fragments after digestion,
        Number of fragments with molecular size above max_band, 
        Number of fragments with molecular size between max_band and min_band, 
        Number of fragments with molecular size below min_band)}
    """
    from Bio.Restriction import RestrictionBatch
    count = 0
    result = {}
    for enzyme in RestrictionBatch(first=[], 
                                   suppliers=[x.upper() for x in suppliers]):
        try:
            digest = restriction_digest(seq, enzyme, max_band, min_band,
                                        linear, p)
        except MemoryError:
            print 'Memory Error during ' + str(enzyme) + ' digestion'
        result[str(enzyme)] = (digest[0], len(digest[1]),
                               len(digest[2]), len(digest[3]))
        count = count + 1
        if p != 'yes':
            if count % 10 == 0:
                print str(count) + ' restriction endonuclease processed'
    return result
    
def generation(A2, A1, min2, min1,
               conv=50000000/0.3,
               limit=0.301,
               gradient=52137400,
               intercept=118718650):
    """
    Calculates the number of generations and generation time using
    turbidity measurement of cell culture (usually OD600 readings)
    between 2 time points (min1 and min2).
    
    Parameters:
        A2 = turbidity measurement at min2.
        A1 = turbidity measurement at min1.
        conv = conversion ratio between OD readings to cell count.
            Default is 0.3 OD = 5e7 (50 million) cells, standard for
            Escherichia coli.
        limit = OD reading at which limit of proportionality of the
            conversion ratio no longer holds, such as cell size decrease
            or increase with higher OD readings.
            Default is 0.301, for Escherichia coli.
        gradient and intercept = the gradient and intercept for cell
            number correction when OD is above limit of proportionality.
            Correction equation:
                cell count = gradient * ln(OD) + intercept
            Default value of gradient is 52137400 and intercept is
            118718650.

        Limit of proportionality, correction gradient and intercept
        are reverse engineered from the graph of Sezonov, Guennadi,
        Joseleau-Petit, Daniele and D'Ari, Richard. 2007. Escherichia
        coli Physiology in Luria-Bertani Broth. Journal of Bacteriology
        189(23):8746-8749
    
    Returns:
        (number of generations between min1 and min2,
        length of time (in minutes) for each generation (generation time),
        number of cells per ml at min2,
        number of cells per ml at min1)
    """
    if A1 < limit:
        y = A1 * conv
    else:
        y = gradient * math.log(A1, math.e) + intercept
    if A2 < limit:
        x = A2 * conv
    else:
        x = gradient * math.log(A2, math.e) + intercept
    gen = (math.log10(x) - math.log10(y))/math.log10(2)
    time_diff = min2 - min1 
    return (gen, time_diff/gen, x, y)

def totalgen(ODs, p='yes', dilution=100,
             conv=50000000/0.3, limit=0.301,
             gradient=52137400, intercept=118718650):
    """
    Parameters:
        ODs = list of OD readings at the start of next subculture.
        p = flag to determine if the data is to be printed. Default = yes
        dilution = dilution factor between each passage. Default = 100
        conv = conversion ratio between OD readings to cell count.
            Default is 0.3 OD = 5e7 (50 million) cells, standard for
            Escherichia coli.
        limit = OD reading at which limit of proportionality of the
            conversion ratio no longer holds, such as cell size decrease
            or increase with higher OD readings.
            Default is 0.301, for Escherichia coli.
        gradient and intercept = the gradient and intercept for cell
            number correction when OD is above limit of proportionality.
            Correction equation:
                cell count = gradient * ln(OD) + intercept
            Default value of gradient is 52137400 and intercept is
            118718650.

        Limit of proportionality, correction gradient and intercept
        are reverse engineered from the graph of Sezonov, Guennadi,
        Joseleau-Petit, Daniele and D'Ari, Richard. 2007. Escherichia
        coli Physiology in Luria-Bertani Broth. Journal of Bacteriology
        189(23):8746-8749
    """
    ODs = [float(x) for x in ODs if x != '']
    gen_list = [0] * (len(ODs) - 1)
    for passage in range(len(ODs)-1):
        if ODs[passage] < limit:
            initial_count = ODs[passage] * conv
        else:
            initial_count = gradient * math.log(ODs[passage], math.e) + \
                            intercept
        if ODs[passage+1] < limit:
            final_count = ODs[passage+1] * limit
        else:
            final_count = gradient * math.log(ODs[passage+1], math.e) + \
                          intercept
        initial_count = initial_count / float(dilution)
        gen = (math.log10(final_count) - \
               math.log10(initial_count)) / math.log10(2)
        if gen < 0: gen = 0.0
        gen_list[passage] = gen
        if p == 'yes':
            print 'Number of cells inoculate from Passage ' + \
                  str(passage) + ' = ' +str(initial_count)
            print 'Number of cells at subculture from Passage ' + \
                  str(passage+1) + ' = ' +str(final_count)
            print 'Between Passage ' + str(passage) + ' and Passage ' + \
                  str(passage+1) + ', Number of generations = ' + \
                  str(gen_list[passage])
            print 'Total number of generations since Passage 0 = ' + \
                  str(sum(gen_list))
            print
    return gen_list

def setCompare(original, test, absent):
    """
    Used for processing set-based (unordered or nominal) distance of 
    categorical data.
    
    Parameters:
        original: list of original data
        test: list of data to test against original
        absent: indicator to define absent data
    """
    original_only = float(len([x for x in original
                               if x not in test]))
    test_only = float(len([x for x in test if x not in original]))
    both = float(len([x for x in original if x in test]))
    return (original_only, test_only, both)

def listCompare(original, test, absent):
    """
    Used for processing list-based (ordered or ordinal) distance of 
    categorical data.
    
    Parameters:
        original: list of original data
        test: list of data to test against original
        absent: indicator to define absent data
    """
    original = list(original)
    test = list(test)
    original_only = 0.0
    test_only = 0.0
    both = 0.0
    for i in range(len(original)):
        if original[i] == absent and test[i] == absent: pass
        elif original[i] == test[i]: both = both + 1
        elif original[i] <> absent and test[i] == absent:
            original_only = original_only + 1
        elif original[i] == absent and test[i] <> absent: 
            test_only = test_only + 1
        else: pass
    return (original_only, test_only, both)

def Nei_Li(original, test, absent=0, type='Set'):
    """
    Nei and Li Distance is distance measure for nominal or ordinal data.
    
    Given 2 lists (original and test), calculates the Nei and Li Distance 
    based on the formula,
    
    1 - [2 x (number of regions where both species are present)/
    [(2 x (number of regions where both species are present)) + 
    (number of regions where only one species is present)]]
        
    @see: Nei M, Li WH (1979) Mathematical models for studying genetic
    variation in terms of restriction endonucleases.
    Proc Natl Acad Sci USA 76:5269-5273
    
    @param original: list of original data
    @param test: list of data to test against original
    @param absent: user-defined identifier for absent of region, default = 0
    @param type: {Set | List}, define whether use Set comparison (unordered) or
        list comparison (ordered), default = Set
    """
    if type == 'Set':
        (original_only, test_only, both) = setCompare(original, test, absent)
    else:
        (original_only, test_only, both) = listCompare(original, test, absent)
    return 1-((2*both)/((2*both)+original_only+test_only))
    
def randomization(statfunction, fulldata, testdata, iteration=1000):
    """
    Test harness for statistical randomization test, also known as
    permutation test.

    Pitman, EJG. 1938. Significance tests which may be applied to samples
    from any population. Part III. The analysis of variance test.
    Biometrika 29: 322-335. 
    Manly, Bryan FJ. 2007. Randomization, Bootstrap and Monte Carlo
    Methods in Biology (3rd edition). Chapman & Hall/CRC.

    Parameters:
        statfunction = Python function to calculate the test statistic.
        fulldata = list of entire data set (for randomization)
        testdata = list of sample data of interest (for testing)
        iteration = number of times random samples are drawn.
            Default = 1000

    Returns:
        Proportion where statistic from randomized sample is greater
        or equal to the statistic from testdata. This can be taken as
        p-value for the test
    """
    from copads.Operations import sample_wr
    test_statistic = statfunction(testdata)
    randomized_statistic = [statfunction(sample_wr(fulldata, len(testdata))) 
                            for i in range(iteration)]
    #print randomized_statistic, test_statistic
    more = [1 for x in randomized_statistic
                if x >= test_statistic]
    return sum(more) / float(len(randomized_statistic))

def bootstrap(data, iteration=1000):
    """
    Calculates bootstrapped means and standard deviation.
    
    Efron, Bradley. 1979. Bootstrap methods: Another look at the jackknife.
    The Annals of Statistics 7:1-26. 
    Manly, Bryan FJ. 2007. Randomization, Bootstrap and Monte Carlo
    Methods in Biology (3rd edition). Chapman & Hall/CRC.

    Parameters:
        data = list of data to generate bootstrapped samples from.
        iterations = number of times bootstrapped samples are drawn.
            Default = 1000

    Returns:
        (bootstrapped means, bootstrapped standard deviation)
    """
    from copads.Operations import sample_wr
    len_data = len(data)
    pool = [sum(sample_wr(data, len_data)) / float(len_data)
            for x in range(iteration)]
    poolmeans = float(sum(pool)) / float(len(pool))
    div = [(x - poolmeans)**2 for x in pool]
    stdev = math.sqrt(sum(div)) / (len(pool) - 1)
    return (poolmeans, stdev)

def electrophoresis_mw(marker, samples):
    """
    Parameters:
        marker = data of the marker lane in the format of
            [list of migration distance, list of molecular weights]
        samples = 
    """
    from copads.SampleStatistics import TwoSample
    if len(marker[0]) != len(marker[1]):
        raise AttributeError, 'Number of molecular weights not equal to the \
        number of migration distances'
    marker[1] = [math.log10(x) for x in marker[1]]
    (gradient, intercept) = TwoSample(marker[0], 'dist', 
                                      marker[1], 'mw').linear_regression()
    return [[10 ** (gradient * band) + 10 ** intercept 
            for band in sample] 
                for sample in samples]
    

